
ALTER TABLE payments ADD COLUMN end_date DATE;
ALTER TABLE payments ADD COLUMN installment_count INTEGER;
ALTER TABLE payments ADD COLUMN current_installment INTEGER DEFAULT 1;
