
ALTER TABLE payments ADD COLUMN asaas_payment_id TEXT;
ALTER TABLE payments ADD COLUMN asaas_status TEXT;
ALTER TABLE payments ADD COLUMN send_to_asaas BOOLEAN DEFAULT FALSE;
ALTER TABLE payments ADD COLUMN billing_type TEXT;

-- Update existing payment types to new enum values
UPDATE payments SET type = 'one_time' WHERE type = 'implementation';
UPDATE payments SET type = 'recurring' WHERE type = 'monthly';
