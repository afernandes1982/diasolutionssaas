
-- Remove new fields from developers table
ALTER TABLE developers DROP COLUMN fixed_value;
ALTER TABLE developers DROP COLUMN commission_percentage;
