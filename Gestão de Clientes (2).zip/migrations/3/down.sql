
-- Revert payment types
UPDATE payments SET type = 'implementation' WHERE type = 'one_time';
UPDATE payments SET type = 'monthly' WHERE type = 'recurring';

ALTER TABLE payments DROP COLUMN asaas_payment_id;
ALTER TABLE payments DROP COLUMN asaas_status;
ALTER TABLE payments DROP COLUMN send_to_asaas;
ALTER TABLE payments DROP COLUMN billing_type;
