
DROP TABLE projects;
