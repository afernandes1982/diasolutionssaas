
DROP TABLE payments;
DROP TABLE client_checklist_items;
DROP TABLE client_checklists;
DROP TABLE checklist_template_items;
DROP TABLE checklist_templates;
DROP TABLE clients;
