
DROP TABLE user_profiles;
