
ALTER TABLE user_subscriptions ADD COLUMN mercado_pago_preference_id TEXT;
ALTER TABLE user_subscriptions ADD COLUMN mercado_pago_payment_id TEXT;
