
DROP TABLE user_subscriptions;
DROP TABLE subscription_plans;
