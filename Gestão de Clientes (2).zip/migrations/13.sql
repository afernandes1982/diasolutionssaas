
CREATE TABLE project_developers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  developer_id INTEGER NOT NULL,
  role TEXT DEFAULT 'developer',
  hours_allocated REAL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
