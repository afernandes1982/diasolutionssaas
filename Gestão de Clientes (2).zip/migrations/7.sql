
-- Add sample subscription plans if they don't exist
INSERT OR IGNORE INTO subscription_plans (id, name, description, monthly_price, annual_price, max_clients, max_templates, features, is_active)
VALUES 
  ('starter', 'Plano Starter', 'Ideal para pequenos negócios', 29.90, 299.00, 20, 3, '["Até 20 clientes", "3 templates", "Suporte por email"]', TRUE),
  ('professional', 'Plano Professional', 'Para empresas em crescimento', 79.90, 799.00, 100, 10, '["Até 100 clientes", "10 templates", "Automações básicas", "Suporte prioritário"]', TRUE),
  ('business', 'Plano Business', 'Para empresas estabelecidas', 149.90, 1499.00, 500, -1, '["Até 500 clientes", "Templates ilimitados", "Automações avançadas", "Relatórios detalhados", "Integrações"]', TRUE),
  ('enterprise', 'Plano Enterprise', 'Solução completa para grandes empresas', 299.90, 2999.00, -1, -1, '["Clientes ilimitados", "Templates ilimitados", "Todas as funcionalidades", "Suporte 24/7", "API personalizada"]', TRUE);
