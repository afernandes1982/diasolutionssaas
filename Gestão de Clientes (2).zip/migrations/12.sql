
CREATE TABLE developers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  specialization TEXT,
  level TEXT DEFAULT 'junior',
  hourly_rate REAL,
  is_active BOOLEAN DEFAULT TRUE,
  bio TEXT,
  avatar_url TEXT,
  user_id TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
