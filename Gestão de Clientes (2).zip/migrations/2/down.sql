
DELETE FROM checklist_template_items WHERE checklist_template_id = 1;
DELETE FROM checklist_templates WHERE id = 1;
