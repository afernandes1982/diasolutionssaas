
DROP TABLE developers;
