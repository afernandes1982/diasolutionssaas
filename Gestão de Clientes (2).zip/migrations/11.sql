
CREATE TABLE projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  client_id INTEGER,
  project_type TEXT,
  status TEXT DEFAULT 'planejamento',
  start_date DATE,
  estimated_end_date DATE,
  actual_end_date DATE,
  budget REAL,
  progress_percentage INTEGER DEFAULT 0,
  technologies TEXT,
  team_members TEXT,
  notes TEXT,
  user_id TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
