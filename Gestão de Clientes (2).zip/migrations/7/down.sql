
-- Remove sample subscription plans
DELETE FROM subscription_plans WHERE id IN ('starter', 'professional', 'business', 'enterprise');
