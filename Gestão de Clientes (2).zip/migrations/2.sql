
-- Criar um template padrão para novos usuários
INSERT INTO checklist_templates (name, description, is_default, user_id) VALUES 
('Template Padrão - Implementação de IA', 'Template básico para implementação de agentes de IA via WhatsApp', TRUE, 'default');

-- Obter o ID do template criado (assumindo que será 1 para o primeiro)
INSERT INTO checklist_template_items (checklist_template_id, title, description, order_index, is_required, category) VALUES 
(1, 'Configurar conta OpenAI GPT-4', 'Criar conta na OpenAI e configurar API key para GPT-4', 0, TRUE, 'APIs Externas'),
(1, 'Configurar servidor VPS', 'Configurar servidor para hospedar n8n e agente', 1, TRUE, 'Servidor/VPS'),
(1, 'Instalar e configurar n8n', 'Instalar n8n no servidor e configurar acesso', 2, TRUE, 'Configuração'),
(1, 'Configurar WhatsApp Business API', 'Configurar integração com WhatsApp Business API', 3, TRUE, 'APIs Externas'),
(1, 'Criar banco de dados', 'Configurar banco de dados para armazenar conversas e dados', 4, TRUE, 'Banco de Dados'),
(1, 'Desenvolver fluxo do agente', 'Criar workflows no n8n para o agente de IA', 5, TRUE, 'Configuração'),
(1, 'Configurar webhooks', 'Configurar webhooks para receber mensagens do WhatsApp', 6, TRUE, 'Configuração'),
(1, 'Testes de integração', 'Testar funcionamento completo do agente', 7, TRUE, 'Testes'),
(1, 'Documentação técnica', 'Documentar configurações e instruções de uso', 8, FALSE, 'Documentação'),
(1, 'Treinamento do cliente', 'Treinar cliente no uso e manutenção do sistema', 9, TRUE, 'Documentação');
