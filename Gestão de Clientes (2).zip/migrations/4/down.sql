
ALTER TABLE payments DROP COLUMN end_date;
ALTER TABLE payments DROP COLUMN installment_count;
ALTER TABLE payments DROP COLUMN current_installment;
