
ALTER TABLE user_subscriptions DROP COLUMN mercado_pago_preference_id;
ALTER TABLE user_subscriptions DROP COLUMN mercado_pago_payment_id;
