
-- Add new fields to developers table
ALTER TABLE developers ADD COLUMN fixed_value REAL;
ALTER TABLE developers ADD COLUMN commission_percentage REAL;
