
DROP TABLE project_developers;
