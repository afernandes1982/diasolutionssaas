
ALTER TABLE user_subscriptions ADD COLUMN mercado_pago_preference_id TEXT;
ALTER TABLE user_subscriptions ADD COLUMN mercado_pago_payment_id TEXT;
ALTER TABLE user_subscriptions DROP COLUMN stripe_payment_intent_id;
ALTER TABLE user_subscriptions DROP COLUMN stripe_customer_id;
