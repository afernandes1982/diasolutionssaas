import z from "zod";

// Schema para clientes
export const ClientSchema = z.object({
  id: z.number(),
  name: z.string(),
  email: z.string(),
  phone: z.string().nullable(),
  company: z.string().nullable(),
  website: z.string().nullable(),
  description: z.string().nullable(),
  status: z.string(),
  contract_start_date: z.string().nullable(),
  contract_end_date: z.string().nullable(),
  implementation_fee: z.number().nullable(),
  monthly_fee: z.number().nullable(),
  is_implementation_paid: z.boolean(),
  user_id: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateClientSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório'),
  email: z.string().email('Email inválido'),
  phone: z.string().optional(),
  company: z.string().optional(),
  website: z.string().optional(),
  description: z.string().optional(),
  contract_start_date: z.string().optional(),
  contract_end_date: z.string().optional(),
  implementation_fee: z.number().optional(),
  monthly_fee: z.number().optional(),
});

export const UpdateClientSchema = CreateClientSchema.partial();

// Schema para templates de checklist
export const ChecklistTemplateSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  is_default: z.boolean(),
  user_id: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateChecklistTemplateSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório'),
  description: z.string().optional(),
  is_default: z.boolean().optional(),
});

// Schema para itens do template
export const ChecklistTemplateItemSchema = z.object({
  id: z.number(),
  checklist_template_id: z.number(),
  title: z.string(),
  description: z.string().nullable(),
  order_index: z.number(),
  is_required: z.boolean(),
  category: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateChecklistTemplateItemSchema = z.object({
  title: z.string().min(1, 'Título é obrigatório'),
  description: z.string().optional(),
  order_index: z.number().optional(),
  is_required: z.boolean().optional(),
  category: z.string().optional(),
});

// Schema para checklists de cliente
export const ClientChecklistSchema = z.object({
  id: z.number(),
  client_id: z.number(),
  checklist_template_id: z.number(),
  name: z.string(),
  is_completed: z.boolean(),
  completed_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateClientChecklistSchema = z.object({
  client_id: z.number(),
  checklist_template_id: z.number(),
  name: z.string().optional(),
});

// Schema para itens do checklist de cliente
export const ClientChecklistItemSchema = z.object({
  id: z.number(),
  client_checklist_id: z.number(),
  checklist_template_item_id: z.number(),
  title: z.string(),
  description: z.string().nullable(),
  is_completed: z.boolean(),
  completed_at: z.string().nullable(),
  notes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const UpdateClientChecklistItemSchema = z.object({
  is_completed: z.boolean().optional(),
  notes: z.string().optional(),
});

// Schema para pagamentos
export const PaymentSchema = z.object({
  id: z.number(),
  client_id: z.number(),
  type: z.enum(['implementation', 'monthly', 'recurring', 'one_time']),
  amount: z.number(),
  due_date: z.string(),
  paid_date: z.string().nullable(),
  is_paid: z.boolean(),
  payment_method: z.string().nullable(),
  notes: z.string().nullable(),
  invoice_number: z.string().nullable(),
  asaas_payment_id: z.string().nullable(),
  asaas_status: z.string().nullable(),
  send_to_asaas: z.boolean(),
  billing_type: z.enum(['BOLETO', 'CREDIT_CARD', 'PIX', 'UNDEFINED']).nullable(),
  end_date: z.string().nullable(),
  installment_count: z.number().nullable(),
  current_installment: z.number().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreatePaymentSchema = z.object({
  client_id: z.number(),
  type: z.enum(['implementation', 'monthly', 'recurring', 'one_time']),
  amount: z.number().min(0.01, 'Valor deve ser maior que 0'),
  due_date: z.string(),
  payment_method: z.string().optional(),
  notes: z.string().optional(),
  invoice_number: z.string().optional(),
  send_to_asaas: z.boolean().optional(),
  billing_type: z.enum(['BOLETO', 'CREDIT_CARD', 'PIX', 'UNDEFINED']).optional(),
  end_date: z.string().optional(),
  installment_count: z.number().min(1, 'Número de parcelas deve ser maior que 0').optional(),
});

// Tipos derivados
export type ClientType = z.infer<typeof ClientSchema>;
export type CreateClientType = z.infer<typeof CreateClientSchema>;
export type UpdateClientType = z.infer<typeof UpdateClientSchema>;

export type ChecklistTemplateType = z.infer<typeof ChecklistTemplateSchema>;
export type CreateChecklistTemplateType = z.infer<typeof CreateChecklistTemplateSchema>;

export type ChecklistTemplateItemType = z.infer<typeof ChecklistTemplateItemSchema>;
export type CreateChecklistTemplateItemType = z.infer<typeof CreateChecklistTemplateItemSchema>;

export type ClientChecklistType = z.infer<typeof ClientChecklistSchema>;
export type CreateClientChecklistType = z.infer<typeof CreateClientChecklistSchema>;

export type ClientChecklistItemType = z.infer<typeof ClientChecklistItemSchema>;
export type UpdateClientChecklistItemType = z.infer<typeof UpdateClientChecklistItemSchema>;

export type PaymentType = z.infer<typeof PaymentSchema>;
export type CreatePaymentType = z.infer<typeof CreatePaymentSchema>;

// Schema para assinaturas
export const SubscriptionSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  plan_id: z.string(),
  status: z.string(),
  billing_cycle: z.string(),
  amount: z.number(),
  start_date: z.string(),
  end_date: z.string().nullable(),
  next_billing_date: z.string().nullable(),
  payment_method: z.string().nullable(),
  asaas_subscription_id: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateSubscriptionSchema = z.object({
  planId: z.string(),
  billingCycle: z.enum(['monthly', 'annual']),
  paymentMethod: z.enum(['credit_card', 'pix', 'boleto', 'stripe']),
  amount: z.number().min(0.01),
});

export const SubscriptionPlanSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string().nullable(),
  monthly_price: z.number(),
  annual_price: z.number(),
  max_clients: z.number(),
  max_templates: z.number(),
  features: z.string(),
  is_active: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

// Tipos derivados
export type SubscriptionType = z.infer<typeof SubscriptionSchema>;
export type CreateSubscriptionType = z.infer<typeof CreateSubscriptionSchema>;
export type SubscriptionPlanType = z.infer<typeof SubscriptionPlanSchema>;

// Schema para desenvolvedores
export const DeveloperSchema = z.object({
  id: z.number(),
  name: z.string(),
  email: z.string(),
  phone: z.string().nullable(),
  specialization: z.string().nullable(),
  level: z.string(),
  hourly_rate: z.number().nullable(),
  is_active: z.boolean(),
  bio: z.string().nullable(),
  avatar_url: z.string().nullable(),
  user_id: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateDeveloperSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório'),
  email: z.string().email('Email inválido'),
  phone: z.string().optional(),
  specialization: z.string().optional(),
  level: z.enum(['junior', 'pleno', 'senior', 'tech_lead']).optional(),
  hourly_rate: z.number().min(0, 'Valor por hora deve ser positivo').optional(),
  fixed_value: z.number().min(0, 'Valor fixo deve ser positivo').optional(),
  commission_percentage: z.number().min(0, 'Comissão deve ser positiva').max(100, 'Comissão não pode ser maior que 100%').optional(),
  bio: z.string().optional(),
  avatar_url: z.string().optional(),
});

export const UpdateDeveloperSchema = CreateDeveloperSchema.partial();

// Schema para projetos
export const ProjectSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  client_id: z.number().nullable(),
  project_type: z.string().nullable(),
  status: z.string(),
  start_date: z.string().nullable(),
  estimated_end_date: z.string().nullable(),
  actual_end_date: z.string().nullable(),
  budget: z.number().nullable(),
  progress_percentage: z.number(),
  technologies: z.string().nullable(),
  team_members: z.string().nullable(),
  notes: z.string().nullable(),
  user_id: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateProjectSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório'),
  description: z.string().optional(),
  client_id: z.number().optional(),
  project_type: z.string().optional(),
  status: z.enum(['planejamento', 'em_andamento', 'pausado', 'concluido', 'cancelado']).optional(),
  start_date: z.string().optional(),
  estimated_end_date: z.string().optional(),
  budget: z.number().min(0, 'Orçamento deve ser positivo').optional(),
  progress_percentage: z.number().min(0).max(100).optional(),
  technologies: z.array(z.string()).optional(),
  notes: z.string().optional(),
  developer_ids: z.array(z.number()).optional(),
});

export const UpdateProjectSchema = CreateProjectSchema.partial();

// Tipos derivados
export type DeveloperType = z.infer<typeof DeveloperSchema>;
export type CreateDeveloperType = z.infer<typeof CreateDeveloperSchema>;
export type UpdateDeveloperType = z.infer<typeof UpdateDeveloperSchema>;

export type ProjectType = z.infer<typeof ProjectSchema>;
export type CreateProjectType = z.infer<typeof CreateProjectSchema>;
export type UpdateProjectType = z.infer<typeof UpdateProjectSchema>;
