import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import {
  CreateClientSchema,
  UpdateClientSchema,
  CreateChecklistTemplateSchema,
  CreateChecklistTemplateItemSchema,
  CreateClientChecklistSchema,
  UpdateClientChecklistItemSchema,
  CreatePaymentSchema,
  CreateSubscriptionSchema,
  CreateDeveloperSchema,
  UpdateDeveloperSchema,
  CreateProjectSchema,
  UpdateProjectSchema,
} from "@/shared/types";
import Stripe from 'stripe';

const app = new Hono<{ Bindings: Env }>();

// Auth endpoints
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();
  const code = body.code;

  if (!code) {
    return c.json({ error: "Código de autorização não fornecido" }, 400);
  }

  try {
    const sessionToken = await exchangeCodeForSessionToken(code, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: "/",
      sameSite: "none",
      secure: true,
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    return c.json({ error: "Falha na autenticação" }, 401);
  }
});

app.get("/api/users/me", authMiddleware, async (c) => {
  const user = c.get("user");
  return c.json(user);
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Client endpoints
app.get('/api/clients', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  const { results } = await c.env.DB.prepare(
    'SELECT * FROM clients WHERE user_id = ? ORDER BY created_at DESC'
  ).bind(user.id).all();

  return c.json(results);
});

app.post('/api/clients', authMiddleware, zValidator('json', CreateClientSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const data = c.req.valid('json');

  const result = await c.env.DB.prepare(`
    INSERT INTO clients (name, email, phone, company, website, description, 
                        contract_start_date, contract_end_date, implementation_fee, 
                        monthly_fee, user_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    data.name,
    data.email,
    data.phone || null,
    data.company || null,
    data.website || null,
    data.description || null,
    data.contract_start_date || null,
    data.contract_end_date || null,
    data.implementation_fee || null,
    data.monthly_fee || null,
    user.id
  ).run();

  if (result.success) {
    const client = await c.env.DB.prepare(
      'SELECT * FROM clients WHERE id = ?'
    ).bind(result.meta.last_row_id).first();
    
    return c.json(client, 201);
  }

  return c.json({ error: 'Falha ao criar cliente' }, 500);
});

app.put('/api/clients/:id', authMiddleware, zValidator('json', UpdateClientSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const clientId = c.req.param('id');
  const data = c.req.valid('json');

  // Verificar se o cliente pertence ao usuário
  const existing = await c.env.DB.prepare(
    'SELECT * FROM clients WHERE id = ? AND user_id = ?'
  ).bind(clientId, user.id).first();

  if (!existing) {
    return c.json({ error: 'Cliente não encontrado' }, 404);
  }

  const updates = Object.entries(data).filter(([_, value]) => value !== undefined);
  if (updates.length === 0) {
    return c.json(existing);
  }

  const setClause = updates.map(([key]) => `${key} = ?`).join(', ');
  const values = updates.map(([_, value]) => value);

  await c.env.DB.prepare(`
    UPDATE clients SET ${setClause}, updated_at = CURRENT_TIMESTAMP 
    WHERE id = ? AND user_id = ?
  `).bind(...values, clientId, user.id).run();

  const updated = await c.env.DB.prepare(
    'SELECT * FROM clients WHERE id = ?'
  ).bind(clientId).first();

  return c.json(updated);
});

app.delete('/api/clients/:id', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const clientId = c.req.param('id');

  const result = await c.env.DB.prepare(
    'DELETE FROM clients WHERE id = ? AND user_id = ?'
  ).bind(clientId, user.id).run();

  if (!result.success) {
    return c.json({ error: 'Cliente não encontrado' }, 404);
  }

  return c.json({ success: true });
});

// Checklist template endpoints
app.get('/api/checklist-templates', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  const { results } = await c.env.DB.prepare(`
    SELECT ct.*, 
           COUNT(cti.id) as items_count
    FROM checklist_templates ct
    LEFT JOIN checklist_template_items cti ON ct.id = cti.checklist_template_id
    WHERE ct.user_id = ? OR ct.user_id = 'default'
    GROUP BY ct.id
    ORDER BY ct.is_default DESC, ct.created_at DESC
  `).bind(user.id).all();

  return c.json(results);
});

app.get('/api/checklist-templates/:id/items', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const templateId = c.req.param('id');

  // Verificar se o template pertence ao usuário ou é um template padrão
  const template = await c.env.DB.prepare(
    'SELECT * FROM checklist_templates WHERE id = ? AND (user_id = ? OR user_id = \'default\')'
  ).bind(templateId, user.id).first();

  if (!template) {
    return c.json({ error: 'Template não encontrado' }, 404);
  }

  const { results } = await c.env.DB.prepare(`
    SELECT * FROM checklist_template_items 
    WHERE checklist_template_id = ? 
    ORDER BY order_index ASC, created_at ASC
  `).bind(templateId).all();

  return c.json(results);
});

app.post('/api/checklist-templates', authMiddleware, zValidator('json', CreateChecklistTemplateSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const data = c.req.valid('json');

  const result = await c.env.DB.prepare(`
    INSERT INTO checklist_templates (name, description, is_default, user_id)
    VALUES (?, ?, ?, ?)
  `).bind(
    data.name,
    data.description || null,
    data.is_default || false,
    user.id
  ).run();

  if (result.success) {
    const template = await c.env.DB.prepare(
      'SELECT * FROM checklist_templates WHERE id = ?'
    ).bind(result.meta.last_row_id).first();
    
    return c.json(template, 201);
  }

  return c.json({ error: 'Falha ao criar template' }, 500);
});

app.post('/api/checklist-templates/:id/items', authMiddleware, zValidator('json', CreateChecklistTemplateItemSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const templateId = c.req.param('id');
  const data = c.req.valid('json');

  // Verificar se o template pertence ao usuário
  const template = await c.env.DB.prepare(
    'SELECT * FROM checklist_templates WHERE id = ? AND user_id = ?'
  ).bind(templateId, user.id).first();

  if (!template) {
    return c.json({ error: 'Template não encontrado' }, 404);
  }

  const result = await c.env.DB.prepare(`
    INSERT INTO checklist_template_items (checklist_template_id, title, description, order_index, is_required, category)
    VALUES (?, ?, ?, ?, ?, ?)
  `).bind(
    templateId,
    data.title,
    data.description || null,
    data.order_index || 0,
    data.is_required || true,
    data.category || null
  ).run();

  if (result.success) {
    const item = await c.env.DB.prepare(
      'SELECT * FROM checklist_template_items WHERE id = ?'
    ).bind(result.meta.last_row_id).first();
    
    return c.json(item, 201);
  }

  return c.json({ error: 'Falha ao criar item' }, 500);
});

app.delete('/api/checklist-templates/:id', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const templateId = c.req.param('id');

  const result = await c.env.DB.prepare(
    'DELETE FROM checklist_templates WHERE id = ? AND user_id = ?'
  ).bind(templateId, user.id).run();

  if (!result.success) {
    return c.json({ error: 'Template não encontrado' }, 404);
  }

  return c.json({ success: true });
});

app.delete('/api/checklist-template-items/:id', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const itemId = c.req.param('id');

  // Verificar se o item pertence ao usuário através do template
  const item = await c.env.DB.prepare(`
    SELECT cti.* FROM checklist_template_items cti
    JOIN checklist_templates ct ON cti.checklist_template_id = ct.id
    WHERE cti.id = ? AND ct.user_id = ?
  `).bind(itemId, user.id).first();

  if (!item) {
    return c.json({ error: 'Item não encontrado' }, 404);
  }

  const result = await c.env.DB.prepare(
    'DELETE FROM checklist_template_items WHERE id = ?'
  ).bind(itemId).run();

  if (!result.success) {
    return c.json({ error: 'Falha ao excluir item' }, 500);
  }

  return c.json({ success: true });
});

// Payment endpoints
app.get('/api/payments', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  const { results } = await c.env.DB.prepare(`
    SELECT p.*, c.name as client_name
    FROM payments p
    JOIN clients c ON p.client_id = c.id
    WHERE c.user_id = ?
    ORDER BY p.due_date DESC
  `).bind(user.id).all();

  return c.json(results);
});

app.post('/api/payments', authMiddleware, zValidator('json', CreatePaymentSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const data = c.req.valid('json');

  // Verificar se o cliente pertence ao usuário
  const client = await c.env.DB.prepare(
    'SELECT * FROM clients WHERE id = ? AND user_id = ?'
  ).bind(data.client_id, user.id).first();

  if (!client) {
    return c.json({ error: 'Cliente não encontrado' }, 404);
  }

  let asaasPaymentId = null;
  let asaasStatus = null;

  // Se deve enviar para o Asaas, criar cobrança
  if (data.send_to_asaas) {
    try {
      const asaasResponse = await fetch('https://api.asaas.com/v3/payments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'access_token': c.env.ASAAS_API_KEY,
        },
        body: JSON.stringify({
          customer: client.asaas_customer_id || await createAsaasCustomer(c.env.ASAAS_API_KEY, client),
          billingType: data.billing_type || 'UNDEFINED',
          value: data.amount,
          dueDate: data.due_date,
          description: `${data.type === 'recurring' ? 'Mensalidade' : data.type === 'one_time' ? 'Taxa única' : 'Implementação'} - ${client.name}`,
          externalReference: data.invoice_number || undefined,
        }),
      });

      if (asaasResponse.ok) {
        const asaasData = await asaasResponse.json() as any;
        asaasPaymentId = asaasData.id;
        asaasStatus = asaasData.status;
      }
    } catch (error) {
      console.error('Erro ao criar cobrança no Asaas:', error);
    }
  }

  const result = await c.env.DB.prepare(`
    INSERT INTO payments (client_id, type, amount, due_date, payment_method, notes, invoice_number, 
                         send_to_asaas, billing_type, asaas_payment_id, asaas_status, end_date, installment_count)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    data.client_id,
    data.type,
    data.amount,
    data.due_date,
    data.payment_method || null,
    data.notes || null,
    data.invoice_number || null,
    data.send_to_asaas || false,
    data.billing_type || null,
    asaasPaymentId,
    asaasStatus,
    data.end_date || null,
    data.installment_count || null
  ).run();

  if (result.success) {
    const payment = await c.env.DB.prepare(
      'SELECT * FROM payments WHERE id = ?'
    ).bind(result.meta.last_row_id).first();
    
    return c.json(payment, 201);
  }

  return c.json({ error: 'Falha ao criar pagamento' }, 500);
});

// Função auxiliar para criar cliente no Asaas
async function createAsaasCustomer(apiKey: string, client: any) {
  try {
    const response = await fetch('https://api.asaas.com/v3/customers', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'access_token': apiKey,
      },
      body: JSON.stringify({
        name: client.name,
        email: client.email,
        phone: client.phone || undefined,
        cpfCnpj: client.cpf_cnpj || undefined,
        company: client.company || undefined,
      }),
    });

    if (response.ok) {
      const customerData = await response.json() as any;
      return customerData.id;
    }
  } catch (error) {
    console.error('Erro ao criar cliente no Asaas:', error);
  }
  return null;
}

app.patch('/api/payments/:id/mark-paid', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const paymentId = c.req.param('id');

  // Verificar se o pagamento pertence ao usuário
  const payment = await c.env.DB.prepare(`
    SELECT p.* FROM payments p
    JOIN clients cl ON p.client_id = cl.id
    WHERE p.id = ? AND cl.user_id = ?
  `).bind(paymentId, user.id).first();

  if (!payment) {
    return c.json({ error: 'Pagamento não encontrado' }, 404);
  }

  await c.env.DB.prepare(`
    UPDATE payments SET is_paid = TRUE, paid_date = DATE('now'), updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(paymentId).run();

  const updated = await c.env.DB.prepare(
    'SELECT * FROM payments WHERE id = ?'
  ).bind(paymentId).first();

  return c.json(updated);
});

app.delete('/api/payments/:id', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const paymentId = c.req.param('id');

  // Verificar se o pagamento pertence ao usuário
  const payment = await c.env.DB.prepare(`
    SELECT p.* FROM payments p
    JOIN clients cl ON p.client_id = cl.id
    WHERE p.id = ? AND cl.user_id = ?
  `).bind(paymentId, user.id).first();

  if (!payment) {
    return c.json({ error: 'Pagamento não encontrado' }, 404);
  }

  const result = await c.env.DB.prepare(
    'DELETE FROM payments WHERE id = ?'
  ).bind(paymentId).run();

  if (!result.success) {
    return c.json({ error: 'Falha ao excluir pagamento' }, 500);
  }

  return c.json({ success: true });
});

// Client checklist endpoints
app.get('/api/client-checklists', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  const { results } = await c.env.DB.prepare(`
    SELECT cc.*, 
           cl.name as client_name,
           cl.company as client_company,
           ct.name as template_name,
           COUNT(cci.id) as items_count,
           COUNT(CASE WHEN cci.is_completed = 1 THEN 1 END) as completed_count
    FROM client_checklists cc
    JOIN clients cl ON cc.client_id = cl.id
    JOIN checklist_templates ct ON cc.checklist_template_id = ct.id
    LEFT JOIN client_checklist_items cci ON cc.id = cci.client_checklist_id
    WHERE cl.user_id = ?
    GROUP BY cc.id
    ORDER BY cc.created_at DESC
  `).bind(user.id).all();

  return c.json(results);
});

app.get('/api/client-checklists/:id/items', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const checklistId = c.req.param('id');

  // Verificar se o checklist pertence ao usuário
  const checklist = await c.env.DB.prepare(`
    SELECT cc.* FROM client_checklists cc
    JOIN clients cl ON cc.client_id = cl.id
    WHERE cc.id = ? AND cl.user_id = ?
  `).bind(checklistId, user.id).first();

  if (!checklist) {
    return c.json({ error: 'Checklist não encontrado' }, 404);
  }

  const { results } = await c.env.DB.prepare(`
    SELECT * FROM client_checklist_items 
    WHERE client_checklist_id = ? 
    ORDER BY id ASC
  `).bind(checklistId).all();

  return c.json(results);
});

app.post('/api/client-checklists', authMiddleware, zValidator('json', CreateClientChecklistSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const data = c.req.valid('json');

  // Verificar se o cliente pertence ao usuário
  const client = await c.env.DB.prepare(
    'SELECT * FROM clients WHERE id = ? AND user_id = ?'
  ).bind(data.client_id, user.id).first();

  if (!client) {
    return c.json({ error: 'Cliente não encontrado' }, 404);
  }

  // Verificar se o template pertence ao usuário ou é um template padrão
  const template = await c.env.DB.prepare(
    'SELECT * FROM checklist_templates WHERE id = ? AND (user_id = ? OR user_id = \'default\')'
  ).bind(data.checklist_template_id, user.id).first();

  if (!template) {
    return c.json({ error: 'Template não encontrado' }, 404);
  }

  const checklistName = data.name || template.name;

  // Criar o checklist
  const result = await c.env.DB.prepare(`
    INSERT INTO client_checklists (client_id, checklist_template_id, name)
    VALUES (?, ?, ?)
  `).bind(data.client_id, data.checklist_template_id, checklistName).run();

  if (!result.success) {
    return c.json({ error: 'Falha ao criar checklist' }, 500);
  }

  const checklistId = result.meta.last_row_id;

  // Buscar itens do template
  const { results: templateItems } = await c.env.DB.prepare(`
    SELECT * FROM checklist_template_items 
    WHERE checklist_template_id = ? 
    ORDER BY order_index ASC, id ASC
  `).bind(data.checklist_template_id).all();

  // Criar itens do checklist baseados no template
  for (const templateItem of templateItems) {
    await c.env.DB.prepare(`
      INSERT INTO client_checklist_items (client_checklist_id, checklist_template_item_id, title, description)
      VALUES (?, ?, ?, ?)
    `).bind(checklistId, templateItem.id, templateItem.title, templateItem.description).run();
  }

  const newChecklist = await c.env.DB.prepare(
    'SELECT * FROM client_checklists WHERE id = ?'
  ).bind(checklistId).first();

  return c.json(newChecklist, 201);
});

app.post('/api/client-checklists/:id/items', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const checklistId = c.req.param('id');
  
  const body = await c.req.json();
  const { title, description } = body;

  if (!title || !title.trim()) {
    return c.json({ error: 'Título é obrigatório' }, 400);
  }

  // Verificar se o checklist pertence ao usuário
  const checklist = await c.env.DB.prepare(`
    SELECT cc.* FROM client_checklists cc
    JOIN clients cl ON cc.client_id = cl.id
    WHERE cc.id = ? AND cl.user_id = ?
  `).bind(checklistId, user.id).first();

  if (!checklist) {
    return c.json({ error: 'Checklist não encontrado' }, 404);
  }

  // Criar o item do checklist
  const result = await c.env.DB.prepare(`
    INSERT INTO client_checklist_items (client_checklist_id, checklist_template_item_id, title, description)
    VALUES (?, 0, ?, ?)
  `).bind(checklistId, title.trim(), description?.trim() || null).run();

  if (!result.success) {
    return c.json({ error: 'Falha ao criar item' }, 500);
  }

  const newItem = await c.env.DB.prepare(
    'SELECT * FROM client_checklist_items WHERE id = ?'
  ).bind(result.meta.last_row_id).first();

  return c.json(newItem, 201);
});

app.patch('/api/client-checklist-items/:id', authMiddleware, zValidator('json', UpdateClientChecklistItemSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const itemId = c.req.param('id');
  const data = c.req.valid('json');

  // Verificar se o item pertence ao usuário
  const item = await c.env.DB.prepare(`
    SELECT cci.* FROM client_checklist_items cci
    JOIN client_checklists cc ON cci.client_checklist_id = cc.id
    JOIN clients cl ON cc.client_id = cl.id
    WHERE cci.id = ? AND cl.user_id = ?
  `).bind(itemId, user.id).first();

  if (!item) {
    return c.json({ error: 'Item não encontrado' }, 404);
  }

  const updates = Object.entries(data).filter(([_, value]) => value !== undefined);
  if (updates.length === 0) {
    return c.json(item);
  }

  let setClause = updates.map(([key]) => `${key} = ?`).join(', ');
  let values = updates.map(([_, value]) => value);

  // Se estiver marcando como completo, adicionar completed_at
  if (data.is_completed === true) {
    setClause += ', completed_at = CURRENT_TIMESTAMP';
  } else if (data.is_completed === false) {
    setClause += ', completed_at = NULL';
  }

  await c.env.DB.prepare(`
    UPDATE client_checklist_items SET ${setClause}, updated_at = CURRENT_TIMESTAMP 
    WHERE id = ?
  `).bind(...values, itemId).run();

  // Verificar se todos os itens do checklist estão completos
  const { results: checklistItems } = await c.env.DB.prepare(`
    SELECT cci.* FROM client_checklist_items cci
    WHERE cci.client_checklist_id = ?
  `).bind(item.client_checklist_id).all();

  const allCompleted = checklistItems.every((item: any) => item.is_completed);
  
  if (allCompleted) {
    await c.env.DB.prepare(`
      UPDATE client_checklists SET is_completed = TRUE, completed_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(item.client_checklist_id).run();
  } else {
    await c.env.DB.prepare(`
      UPDATE client_checklists SET is_completed = FALSE, completed_at = NULL
      WHERE id = ?
    `).bind(item.client_checklist_id).run();
  }

  const updated = await c.env.DB.prepare(
    'SELECT * FROM client_checklist_items WHERE id = ?'
  ).bind(itemId).first();

  return c.json(updated);
});

app.delete('/api/client-checklists/:id', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const checklistId = c.req.param('id');

  // Verificar se o checklist pertence ao usuário
  const checklist = await c.env.DB.prepare(`
    SELECT cc.* FROM client_checklists cc
    JOIN clients cl ON cc.client_id = cl.id
    WHERE cc.id = ? AND cl.user_id = ?
  `).bind(checklistId, user.id).first();

  if (!checklist) {
    return c.json({ error: 'Checklist não encontrado' }, 404);
  }

  const result = await c.env.DB.prepare(
    'DELETE FROM client_checklists WHERE id = ?'
  ).bind(checklistId).run();

  if (!result.success) {
    return c.json({ error: 'Falha ao excluir checklist' }, 500);
  }

  return c.json({ success: true });
});

// Endpoint para sincronizar status do Asaas
app.post('/api/payments/:id/sync-asaas', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const paymentId = c.req.param('id');

  // Verificar se o pagamento pertence ao usuário
  const payment = await c.env.DB.prepare(`
    SELECT p.* FROM payments p
    JOIN clients cl ON p.client_id = cl.id
    WHERE p.id = ? AND cl.user_id = ? AND p.asaas_payment_id IS NOT NULL
  `).bind(paymentId, user.id).first();

  if (!payment) {
    return c.json({ error: 'Pagamento não encontrado ou não enviado para Asaas' }, 404);
  }

  try {
    const response = await fetch(`https://api.asaas.com/v3/payments/${payment.asaas_payment_id}`, {
      headers: {
        'access_token': c.env.ASAAS_API_KEY,
      },
    });

    if (response.ok) {
      const asaasData = await response.json() as any;
      
      await c.env.DB.prepare(`
        UPDATE payments 
        SET asaas_status = ?, is_paid = ?, paid_date = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(
        asaasData.status,
        asaasData.status === 'RECEIVED' ? true : false,
        asaasData.status === 'RECEIVED' ? asaasData.confirmedDate : null,
        paymentId
      ).run();

      const updated = await c.env.DB.prepare(
        'SELECT * FROM payments WHERE id = ?'
      ).bind(paymentId).first();

      return c.json(updated);
    }
  } catch (error) {
    console.error('Erro ao sincronizar com Asaas:', error);
  }

  return c.json({ error: 'Erro ao sincronizar com Asaas' }, 500);
});

// Admin endpoints for subscriber management
app.get('/api/admin/subscribers', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);

  // TODO: Add admin role check here if needed
  // For now, any authenticated user can access admin functions

  try {
    // Since we don't have a users table, we'll get subscription data only
    // User data is managed by Mocha Users Service
    const { results } = await c.env.DB.prepare(`
      SELECT 
        s.user_id as id,
        s.user_id as email,
        s.user_id as name,
        '' as picture,
        s.id as subscription_id,
        s.plan_id,
        sp.name as plan_name,
        s.status,
        s.billing_cycle,
        s.amount,
        s.start_date,
        s.end_date,
        s.next_billing_date,
        CASE 
          WHEN s.next_billing_date IS NOT NULL THEN
            CAST((julianday(s.next_billing_date) - julianday('now')) AS INTEGER)
          WHEN s.end_date IS NOT NULL THEN
            CAST((julianday(s.end_date) - julianday('now')) AS INTEGER)
          ELSE NULL
        END as days_until_expiry,
        CASE 
          WHEN s.status != 'active' THEN 1
          WHEN s.next_billing_date IS NOT NULL AND date(s.next_billing_date) <= date('now') THEN 1
          WHEN s.end_date IS NOT NULL AND date(s.end_date) <= date('now') THEN 1
          ELSE 0
        END as is_expired,
        CASE 
          WHEN s.next_billing_date IS NOT NULL AND 
               date(s.next_billing_date) > date('now') AND 
               date(s.next_billing_date) <= date('now', '+7 days') THEN 1
          WHEN s.end_date IS NOT NULL AND 
               date(s.end_date) > date('now') AND 
               date(s.end_date) <= date('now', '+7 days') THEN 1
          ELSE 0
        END as is_expiring_soon,
        s.created_at
      FROM user_subscriptions s
      LEFT JOIN subscription_plans sp ON s.plan_id = sp.id
      ORDER BY s.created_at DESC
    `).all();

    return c.json(results);
  } catch (error) {
    console.error('Error fetching subscribers:', error);
    return c.json({ error: 'Failed to fetch subscribers' }, 500);
  }
});

app.post('/api/admin/subscribers/:id/block', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  const userId = c.req.param('id');

  try {
    // Update user subscription status to blocked/cancelled
    await c.env.DB.prepare(`
      UPDATE user_subscriptions 
      SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ? AND status = 'active'
    `).bind(userId).run();

    return c.json({ success: true });
  } catch (error) {
    console.error('Error blocking user:', error);
    return c.json({ error: 'Failed to block user' }, 500);
  }
});

app.post('/api/admin/subscribers/:id/unblock', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  const userId = c.req.param('id');

  try {
    // Reactivate most recent subscription
    await c.env.DB.prepare(`
      UPDATE user_subscriptions 
      SET status = 'active', updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ? AND id = (
        SELECT id FROM user_subscriptions 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 1
      )
    `).bind(userId, userId).run();

    return c.json({ success: true });
  } catch (error) {
    console.error('Error unblocking user:', error);
    return c.json({ error: 'Failed to unblock user' }, 500);
  }
});

app.post('/api/admin/check-expired-subscriptions', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);

  try {
    // Auto-expire subscriptions based on end_date or next_billing_date
    await c.env.DB.prepare(`
      UPDATE user_subscriptions 
      SET status = 'expired', updated_at = CURRENT_TIMESTAMP
      WHERE status = 'active' AND (
        (end_date IS NOT NULL AND date(end_date) <= date('now')) OR
        (next_billing_date IS NOT NULL AND date(next_billing_date) <= date('now'))
      )
    `).run();

    return c.json({ success: true });
  } catch (error) {
    console.error('Error checking expired subscriptions:', error);
    return c.json({ error: 'Failed to check expired subscriptions' }, 500);
  }
});

// Subscription endpoints
app.get('/api/subscription-plans', async (c) => {
  const { results } = await c.env.DB.prepare(
    'SELECT * FROM subscription_plans WHERE is_active = TRUE ORDER BY monthly_price ASC'
  ).all();

  return c.json(results);
});

app.get('/api/subscriptions/current', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);

  const subscription = await c.env.DB.prepare(`
    SELECT s.*, 
           sp.name as plan_name, 
           sp.features,
           CASE 
             WHEN s.next_billing_date IS NOT NULL THEN
               CAST((julianday(s.next_billing_date) - julianday('now')) AS INTEGER)
             WHEN s.end_date IS NOT NULL THEN
               CAST((julianday(s.end_date) - julianday('now')) AS INTEGER)
             ELSE NULL
           END as days_until_expiry,
           CASE 
             WHEN s.status != 'active' THEN 1
             WHEN s.next_billing_date IS NOT NULL AND date(s.next_billing_date) <= date('now') THEN 1
             WHEN s.end_date IS NOT NULL AND date(s.end_date) <= date('now') THEN 1
             ELSE 0
           END as is_expired,
           CASE 
             WHEN s.next_billing_date IS NOT NULL AND 
                  date(s.next_billing_date) > date('now') AND 
                  date(s.next_billing_date) <= date('now', '+7 days') THEN 1
             WHEN s.end_date IS NOT NULL AND 
                  date(s.end_date) > date('now') AND 
                  date(s.end_date) <= date('now', '+7 days') THEN 1
             ELSE 0
           END as is_expiring_soon
    FROM user_subscriptions s
    JOIN subscription_plans sp ON s.plan_id = sp.id
    WHERE s.user_id = ? AND s.status = 'active'
    ORDER BY s.created_at DESC
    LIMIT 1
  `).bind(user.id).first();

  return c.json(subscription);
});

app.post('/api/subscriptions/checkout', zValidator('json', CreateSubscriptionSchema), async (c) => {
  // For test checkout, allow without authentication
  const isTest = c.req.header('X-Test-Mode') === 'true';
  let user = null;
  
  if (!isTest) {
    // Apply auth middleware for real checkouts
    const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
    if (!sessionToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    try {
      const response = await fetch(`${c.env.MOCHA_USERS_SERVICE_API_URL}/sessions/${sessionToken}`, {
        headers: { 'Authorization': `Bearer ${c.env.MOCHA_USERS_SERVICE_API_KEY}` }
      });
      
      if (!response.ok) {
        return c.json({ error: 'Unauthorized' }, 401);
      }
      
      user = await response.json();
    } catch {
      return c.json({ error: 'Unauthorized' }, 401);
    }
  }
  
  const data = c.req.valid('json');

  // Verificar se o plano existe
  const plan = await c.env.DB.prepare(
    'SELECT * FROM subscription_plans WHERE id = ? AND is_active = TRUE'
  ).bind(data.planId).first();

  if (!plan) {
    return c.json({ error: 'Plano não encontrado' }, 404);
  }

  // For test mode, just return success without creating real subscription
  if (isTest) {
    return c.json({ 
      subscriptionId: `test_${Date.now()}`,
      success: true,
      testMode: true
    }, 201);
  }

  // Real subscription creation (only if user is authenticated)
  if (!user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  // Handle Stripe payment
  if (data.paymentMethod === 'stripe') {
    try {
      const stripe = new Stripe(c.env.STRIPE_SECRET_KEY);
      
      // Create or get Stripe customer
      let customerId = null;
      const customers = await stripe.customers.list({
        email: user.email,
        limit: 1
      });
      
      if (customers.data.length > 0) {
        customerId = customers.data[0].id;
      } else {
        const customer = await stripe.customers.create({
          email: user.email,
          name: user.google_user_data?.name || 'Cliente',
          metadata: {
            user_id: user.id
          }
        });
        customerId = customer.id;
      }

      // Create payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(data.amount * 100), // Convert to cents
        currency: 'brl',
        customer: customerId,
        metadata: {
          user_id: user.id,
          plan_id: data.planId,
          billing_cycle: data.billingCycle,
          subscription_type: 'new'
        },
        automatic_payment_methods: {
          enabled: true
        }
      });

      // Create subscription with pending status
      const result = await c.env.DB.prepare(`
        INSERT INTO user_subscriptions (user_id, plan_id, status, billing_cycle, amount, start_date, next_billing_date, payment_method, stripe_payment_intent_id, stripe_customer_id)
        VALUES (?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        user.id,
        data.planId,
        data.billingCycle,
        data.amount,
        new Date().toISOString().split('T')[0],
        data.billingCycle === 'annual' 
          ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
          : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        data.paymentMethod,
        paymentIntent.id,
        customerId
      ).run();

      if (result.success) {
        return c.json({
          subscriptionId: result.meta.last_row_id,
          stripe_client_secret: paymentIntent.client_secret,
          stripe_publishable_key: c.env.STRIPE_PUBLISHABLE_KEY,
          success: true
        }, 201);
      }
      
      throw new Error('Failed to create subscription');
      
    } catch (error) {
      console.error('Stripe error:', error);
      return c.json({ error: 'Erro ao processar pagamento com Stripe' }, 500);
    }
  }

  const startDate = new Date().toISOString().split('T')[0];
  const nextBillingDate = data.billingCycle === 'annual' 
    ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  // Cancelar assinatura ativa existente
  await c.env.DB.prepare(`
    UPDATE user_subscriptions 
    SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
    WHERE user_id = ? AND status = 'active'
  `).bind(user.id).run();

  // Criar nova assinatura
  const result = await c.env.DB.prepare(`
    INSERT INTO user_subscriptions (user_id, plan_id, status, billing_cycle, amount, start_date, next_billing_date, payment_method)
    VALUES (?, ?, 'active', ?, ?, ?, ?, ?)
  `).bind(
    user.id,
    data.planId,
    data.billingCycle,
    data.amount,
    startDate,
    nextBillingDate,
    data.paymentMethod
  ).run();

  if (result.success) {
    const subscription = await c.env.DB.prepare(
      'SELECT * FROM user_subscriptions WHERE id = ?'
    ).bind(result.meta.last_row_id).first();
    
    return c.json({ 
      subscriptionId: subscription.id,
      success: true 
    }, 201);
  }

  return c.json({ error: 'Falha ao criar assinatura' }, 500);
});

app.get('/api/subscriptions/:id', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const subscriptionId = c.req.param('id');

  const subscription = await c.env.DB.prepare(`
    SELECT s.*, sp.name as planName
    FROM user_subscriptions s
    JOIN subscription_plans sp ON s.plan_id = sp.id
    WHERE s.id = ? AND s.user_id = ?
  `).bind(subscriptionId, user.id).first();

  if (!subscription) {
    return c.json({ error: 'Assinatura não encontrada' }, 404);
  }

  return c.json(subscription);
});

// Developer endpoints
app.get('/api/developers', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  const { results } = await c.env.DB.prepare(
    'SELECT * FROM developers WHERE user_id = ? ORDER BY name ASC'
  ).bind(user.id).all();

  return c.json(results);
});

app.post('/api/developers', authMiddleware, zValidator('json', CreateDeveloperSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  try {
    const data = c.req.valid('json');
    
    console.log('Creating developer with data:', JSON.stringify(data));
    console.log('User ID:', user.id);

    const result = await c.env.DB.prepare(`
      INSERT INTO developers (name, email, phone, specialization, level, hourly_rate, fixed_value, commission_percentage, bio, avatar_url, user_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.name,
      data.email,
      data.phone || null,
      data.specialization || null,
      data.level || 'junior',
      data.hourly_rate || null,
      data.fixed_value || null,
      data.commission_percentage || null,
      data.bio || null,
      data.avatar_url || null,
      user.id
    ).run();
    
    console.log('Database result:', JSON.stringify(result));

    if (result.success) {
      const developer = await c.env.DB.prepare(
        'SELECT * FROM developers WHERE id = ?'
      ).bind(result.meta.last_row_id).first();
      
      console.log('Created developer:', JSON.stringify(developer));
      return c.json(developer, 201);
    }

    console.error('Database error creating developer:', result);
    return c.json({ error: 'Falha ao criar desenvolvedor' }, 500);
  } catch (error) {
    console.error('Error creating developer:', error);
    return c.json({ error: 'Erro interno do servidor ao criar desenvolvedor' }, 500);
  }
});

app.put('/api/developers/:id', authMiddleware, zValidator('json', UpdateDeveloperSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const developerId = c.req.param('id');
  const data = c.req.valid('json');

  // Verificar se o desenvolvedor pertence ao usuário
  const existing = await c.env.DB.prepare(
    'SELECT * FROM developers WHERE id = ? AND user_id = ?'
  ).bind(developerId, user.id).first();

  if (!existing) {
    return c.json({ error: 'Desenvolvedor não encontrado' }, 404);
  }

  const updates = Object.entries(data).filter(([_, value]) => value !== undefined);
  if (updates.length === 0) {
    return c.json(existing);
  }

  const setClause = updates.map(([key]) => `${key} = ?`).join(', ');
  const values = updates.map(([_, value]) => value);

  await c.env.DB.prepare(`
    UPDATE developers SET ${setClause}, updated_at = CURRENT_TIMESTAMP 
    WHERE id = ? AND user_id = ?
  `).bind(...values, developerId, user.id).run();

  const updated = await c.env.DB.prepare(
    'SELECT * FROM developers WHERE id = ?'
  ).bind(developerId).first();

  return c.json(updated);
});

app.delete('/api/developers/:id', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const developerId = c.req.param('id');

  const result = await c.env.DB.prepare(
    'DELETE FROM developers WHERE id = ? AND user_id = ?'
  ).bind(developerId, user.id).run();

  if (!result.success) {
    return c.json({ error: 'Desenvolvedor não encontrado' }, 404);
  }

  return c.json({ success: true });
});

// Project endpoints (implementing the missing functionality)
app.get('/api/projects', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  
  const { results } = await c.env.DB.prepare(`
    SELECT p.*, c.name as client_name
    FROM projects p
    LEFT JOIN clients c ON p.client_id = c.id
    WHERE p.user_id = ?
    ORDER BY p.created_at DESC
  `).bind(user.id).all();

  // Parse JSON fields
  const projectsWithParsedData = results.map((project: any) => ({
    ...project,
    technologies: project.technologies ? JSON.parse(project.technologies) : [],
    team_members: project.team_members ? JSON.parse(project.team_members) : []
  }));

  return c.json(projectsWithParsedData);
});

app.post('/api/projects', authMiddleware, zValidator('json', CreateProjectSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const data = c.req.valid('json');

  // If client_id is provided, verify it belongs to the user
  if (data.client_id) {
    const client = await c.env.DB.prepare(
      'SELECT * FROM clients WHERE id = ? AND user_id = ?'
    ).bind(data.client_id, user.id).first();

    if (!client) {
      return c.json({ error: 'Cliente não encontrado' }, 404);
    }
  }

  const result = await c.env.DB.prepare(`
    INSERT INTO projects (name, description, client_id, project_type, status, start_date, 
                         estimated_end_date, budget, progress_percentage, technologies, 
                         team_members, notes, user_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    data.name,
    data.description || null,
    data.client_id || null,
    data.project_type || null,
    data.status || 'planejamento',
    data.start_date || null,
    data.estimated_end_date || null,
    data.budget || null,
    data.progress_percentage || 0,
    data.technologies ? JSON.stringify(data.technologies) : null,
    JSON.stringify([]), // team_members will be managed through project_developers table
    data.notes || null,
    user.id
  ).run();

  if (result.success) {
    const projectId = result.meta.last_row_id;

    // Add developers to project if provided
    if (data.developer_ids && data.developer_ids.length > 0) {
      for (const developerId of data.developer_ids) {
        await c.env.DB.prepare(`
          INSERT INTO project_developers (project_id, developer_id, role)
          VALUES (?, ?, 'developer')
        `).bind(projectId, developerId).run();
      }
    }

    const project = await c.env.DB.prepare(
      'SELECT * FROM projects WHERE id = ?'
    ).bind(projectId).first();
    
    return c.json(project, 201);
  }

  return c.json({ error: 'Falha ao criar projeto' }, 500);
});

app.put('/api/projects/:id', authMiddleware, zValidator('json', UpdateProjectSchema), async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const projectId = c.req.param('id');
  const data = c.req.valid('json');

  // Verificar se o projeto pertence ao usuário
  const existing = await c.env.DB.prepare(
    'SELECT * FROM projects WHERE id = ? AND user_id = ?'
  ).bind(projectId, user.id).first();

  if (!existing) {
    return c.json({ error: 'Projeto não encontrado' }, 404);
  }

  // If client_id is being updated, verify it belongs to the user
  if (data.client_id) {
    const client = await c.env.DB.prepare(
      'SELECT * FROM clients WHERE id = ? AND user_id = ?'
    ).bind(data.client_id, user.id).first();

    if (!client) {
      return c.json({ error: 'Cliente não encontrado' }, 404);
    }
  }

  const updates = Object.entries(data).filter(([key, value]) => 
    value !== undefined && key !== 'developer_ids'
  );
  
  if (updates.length > 0) {
    const setClause = updates.map(([key]) => {
      if (key === 'technologies') return `${key} = ?`;
      return `${key} = ?`;
    }).join(', ');
    
    const values = updates.map(([key, value]) => {
      if (key === 'technologies' && Array.isArray(value)) {
        return JSON.stringify(value);
      }
      return value;
    });

    await c.env.DB.prepare(`
      UPDATE projects SET ${setClause}, updated_at = CURRENT_TIMESTAMP 
      WHERE id = ? AND user_id = ?
    `).bind(...values, projectId, user.id).run();
  }

  // Update project developers
  if (data.developer_ids !== undefined) {
    // Remove existing developers
    await c.env.DB.prepare(
      'DELETE FROM project_developers WHERE project_id = ?'
    ).bind(projectId).run();

    // Add new developers
    if (data.developer_ids && data.developer_ids.length > 0) {
      for (const developerId of data.developer_ids) {
        await c.env.DB.prepare(`
          INSERT INTO project_developers (project_id, developer_id, role)
          VALUES (?, ?, 'developer')
        `).bind(projectId, developerId).run();
      }
    }
  }

  const updated = await c.env.DB.prepare(
    'SELECT * FROM projects WHERE id = ?'
  ).bind(projectId).first();

  return c.json(updated);
});

app.delete('/api/projects/:id', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);
  const projectId = c.req.param('id');

  const result = await c.env.DB.prepare(
    'DELETE FROM projects WHERE id = ? AND user_id = ?'
  ).bind(projectId, user.id).run();

  if (!result.success) {
    return c.json({ error: 'Projeto não encontrado' }, 404);
  }

  return c.json({ success: true });
});

// Profile endpoints
app.get('/api/profile', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);

  const profile = await c.env.DB.prepare(
    'SELECT * FROM user_profiles WHERE user_id = ?'
  ).bind(user.id).first();

  if (!profile) {
    // Create default profile with user data
    const defaultProfile = {
      name: user.google_user_data?.name || '',
      email: user.email || '',
      phone: '',
      company: '',
      website: '',
      address: '',
      bio: '',
      profile_picture: user.google_user_data?.picture || ''
    };
    
    await c.env.DB.prepare(`
      INSERT INTO user_profiles (user_id, name, email, phone, company, website, address, bio, profile_picture)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      user.id,
      defaultProfile.name,
      defaultProfile.email,
      defaultProfile.phone,
      defaultProfile.company,
      defaultProfile.website,
      defaultProfile.address,
      defaultProfile.bio,
      defaultProfile.profile_picture
    ).run();

    return c.json(defaultProfile);
  }

  return c.json(profile);
});

app.put('/api/profile', authMiddleware, async (c) => {
  const user = c.get('user');
  if (!user) return c.json({ error: 'Unauthorized' }, 401);

  const data = await c.req.json();

  // Check if profile exists
  const existingProfile = await c.env.DB.prepare(
    'SELECT * FROM user_profiles WHERE user_id = ?'
  ).bind(user.id).first();

  if (existingProfile) {
    // Update existing profile
    await c.env.DB.prepare(`
      UPDATE user_profiles 
      SET name = ?, email = ?, phone = ?, company = ?, website = ?, address = ?, bio = ?, profile_picture = ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).bind(
      data.name || '',
      data.email || '',
      data.phone || '',
      data.company || '',
      data.website || '',
      data.address || '',
      data.bio || '',
      data.profile_picture || '',
      user.id
    ).run();
  } else {
    // Create new profile
    await c.env.DB.prepare(`
      INSERT INTO user_profiles (user_id, name, email, phone, company, website, address, bio, profile_picture)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      user.id,
      data.name || '',
      data.email || '',
      data.phone || '',
      data.company || '',
      data.website || '',
      data.address || '',
      data.bio || '',
      data.profile_picture || ''
    ).run();
  }

  const updatedProfile = await c.env.DB.prepare(
    'SELECT * FROM user_profiles WHERE user_id = ?'
  ).bind(user.id).first();

  return c.json(updatedProfile);
});

// Endpoint para webhook do Asaas
app.post('/webhook/asaas', async (c) => {
  try {
    const body = await c.req.json();
    const event = body.event;
    const payment = body.payment;

    if (event === 'PAYMENT_RECEIVED' || event === 'PAYMENT_CONFIRMED') {
      // Buscar pagamento pelo asaas_payment_id
      const dbPayment = await c.env.DB.prepare(
        'SELECT * FROM payments WHERE asaas_payment_id = ?'
      ).bind(payment.id).first();

      if (dbPayment) {
        await c.env.DB.prepare(`
          UPDATE payments 
          SET is_paid = TRUE, paid_date = ?, asaas_status = ?, updated_at = CURRENT_TIMESTAMP
          WHERE asaas_payment_id = ?
        `).bind(
          payment.confirmedDate || new Date().toISOString().split('T')[0],
          payment.status,
          payment.id
        ).run();
      }
    }

    return c.json({ received: true });
  } catch (error) {
    console.error('Erro no webhook Asaas:', error);
    return c.json({ error: 'Erro no webhook' }, 500);
  }
});

// Endpoint para webhook do Stripe
app.post('/webhook/stripe', async (c) => {
  try {
    const body = await c.req.text();
    const signature = c.req.header('stripe-signature');
    
    if (!signature) {
      return c.json({ error: 'Missing stripe signature' }, 400);
    }

    // In production, you should set the webhook endpoint secret
    // const stripe = new Stripe(c.env.STRIPE_SECRET_KEY);
    // const endpointSecret = c.env.STRIPE_WEBHOOK_SECRET;
    // const event = stripe.webhooks.constructEvent(body, signature, endpointSecret);
    
    // For now, we'll parse the event directly (less secure)
    const event = JSON.parse(body);
    
    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      
      // Find the subscription by payment intent ID
      const subscription = await c.env.DB.prepare(`
        SELECT * FROM user_subscriptions 
        WHERE stripe_payment_intent_id = ? AND status = 'pending'
      `).bind(paymentIntent.id).first();
      
      if (subscription) {
        // Payment succeeded - activate subscription
        await c.env.DB.prepare(`
          UPDATE user_subscriptions 
          SET status = 'active', updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `).bind(subscription.id).run();
        
        // Cancel any other pending subscriptions for this user
        await c.env.DB.prepare(`
          UPDATE user_subscriptions 
          SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
          WHERE user_id = ? AND id != ? AND status = 'pending'
        `).bind(subscription.user_id, subscription.id).run();
      }
    } else if (event.type === 'payment_intent.payment_failed') {
      const paymentIntent = event.data.object;
      
      // Find the subscription by payment intent ID
      const subscription = await c.env.DB.prepare(`
        SELECT * FROM user_subscriptions 
        WHERE stripe_payment_intent_id = ? AND status = 'pending'
      `).bind(paymentIntent.id).first();
      
      if (subscription) {
        // Payment failed - cancel subscription
        await c.env.DB.prepare(`
          UPDATE user_subscriptions 
          SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `).bind(subscription.id).run();
      }
    }

    return c.json({ received: true });
  } catch (error) {
    console.error('Erro no webhook Stripe:', error);
    return c.json({ error: 'Erro no webhook' }, 500);
  }
});

export default app;
