import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from '@getmocha/users-service/react';
import HomePage from "@/react-app/pages/Home";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import DashboardPage from "@/react-app/pages/Dashboard";
import ClientsPage from "@/react-app/pages/Clients";
import ChecklistsPage from "@/react-app/pages/Checklists";
import ProjectsPage from "@/react-app/pages/Projects";
import PaymentsPage from "@/react-app/pages/Payments";
import ReportsPage from "@/react-app/pages/Reports";
import SubscribersPage from "@/react-app/pages/Subscribers";
import CheckoutPage from "@/react-app/pages/Checkout";
import CheckoutSuccessPage from "@/react-app/pages/CheckoutSuccess";
import CheckoutFailurePage from "@/react-app/pages/CheckoutFailure";
import CheckoutPendingPage from "@/react-app/pages/CheckoutPending";
import CheckoutTestPage from "@/react-app/pages/CheckoutTest";
import ProfilePage from "@/react-app/pages/Profile";
import DevelopersPage from "@/react-app/pages/Developers";


export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/clients" element={<ClientsPage />} />
          <Route path="/checklists" element={<ChecklistsPage />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/payments" element={<PaymentsPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/subscribers" element={<SubscribersPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/checkout/success" element={<CheckoutSuccessPage />} />
          <Route path="/checkout/failure" element={<CheckoutFailurePage />} />
          <Route path="/checkout/pending" element={<CheckoutPendingPage />} />
          <Route path="/checkout/test" element={<CheckoutTestPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/developers" element={<DevelopersPage />} />
          
        </Routes>
      </Router>
    </AuthProvider>
  );
}
