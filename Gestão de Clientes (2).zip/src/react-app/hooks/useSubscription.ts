import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';

interface Subscription {
  id: number;
  user_id: string;
  plan_id: string;
  status: string;
  billing_cycle: string;
  amount: number;
  start_date: string;
  end_date: string | null;
  next_billing_date: string | null;
  payment_method: string | null;
  plan_name: string;
  features: string;
  days_until_expiry?: number;
  is_expired: boolean;
  is_expiring_soon: boolean;
  created_at: string;
  updated_at: string;
}

export function useSubscription() {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setSubscription(null);
      setIsLoading(false);
      return;
    }

    const fetchSubscription = async () => {
      try {
        const response = await fetch('/api/subscriptions/current');
        
        if (response.ok) {
          const data = await response.json();
          setSubscription(data);
        } else if (response.status === 404) {
          // Nenhuma assinatura ativa
          setSubscription(null);
        } else {
          throw new Error('Erro ao buscar assinatura');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
      } finally {
        setIsLoading(false);
      }
    };

    fetchSubscription();
  }, [user]);

  const hasActiveSubscription = subscription && subscription.status === 'active' && !subscription.is_expired;

  const canAccess = (feature: string) => {
    if (!hasActiveSubscription) return false;
    
    try {
      const features = JSON.parse(subscription.features || '[]');
      return features.some((f: string) => 
        f.toLowerCase().includes(feature.toLowerCase())
      );
    } catch {
      return false;
    }
  };

  const getPlanLimits = () => {
    if (!subscription) return null;

    // Extrair limites baseados no plano
    const planLimits: Record<string, any> = {
      starter: { clients: 20, templates: 3 },
      professional: { clients: 100, templates: 10 },
      business: { clients: 500, templates: -1 },
      enterprise: { clients: -1, templates: -1 }
    };

    return planLimits[subscription.plan_id] || null;
  };

  return {
    subscription,
    isLoading,
    error,
    hasActiveSubscription,
    canAccess,
    getPlanLimits,
    refresh: () => {
      if (user) {
        setIsLoading(true);
        // Re-trigger the effect
        setSubscription(null);
      }
    }
  };
}
