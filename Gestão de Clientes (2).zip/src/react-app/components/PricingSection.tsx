import { Check, Star, Zap, Crown, Rocket } from 'lucide-react';
import { useState } from 'react';

interface PricingPlan {
  id: string;
  name: string;
  icon: React.ReactNode;
  monthlyPrice: number;
  annualPrice: number;
  description: string;
  features: string[];
  recommended?: boolean;
  maxClients: number | 'unlimited';
  maxTemplates: number | 'unlimited';
}

const plans: PricingPlan[] = [
  {
    id: 'starter',
    name: 'Starter',
    icon: <Star className="w-6 h-6" />,
    monthlyPrice: 19.90,
    annualPrice: 199,
    description: 'Perfeito para agências iniciantes',
    maxClients: 20,
    maxTemplates: 3,
    features: [
      'Até 20 clientes',
      '3 templates de checklist',
      'Controle de pagamentos',
      'Dashboard básico',
      'Suporte por email',
      'Relatórios mensais'
    ]
  },
  {
    id: 'professional',
    name: 'Professional',
    icon: <Zap className="w-6 h-6" />,
    monthlyPrice: 39.90,
    annualPrice: 399,
    description: 'Ideal para agências em crescimento',
    recommended: true,
    maxClients: 100,
    maxTemplates: 10,
    features: [
      'Até 100 clientes',
      '10 templates de checklist',
      'Controle avançado de pagamentos',
      'Dashboard completo com métricas',
      'Relatórios personalizados',
      'Suporte prioritário',
      'Automações básicas',
      'Backup automático'
    ]
  },
  {
    id: 'business',
    name: 'Business',
    icon: <Crown className="w-6 h-6" />,
    monthlyPrice: 59.90,
    annualPrice: 599,
    description: 'Para agências estabelecidas',
    maxClients: 500,
    maxTemplates: 'unlimited',
    features: [
      'Até 500 clientes',
      'Templates ilimitados',
      'Gestão multi-usuário',
      'Analytics avançados',
      'API para integrações',
      'White-label disponível',
      'Suporte telefônico',
      'Treinamento personalizado'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    icon: <Rocket className="w-6 h-6" />,
    monthlyPrice: 99.90,
    annualPrice: 999,
    description: 'Solução completa para grandes agências',
    maxClients: 'unlimited',
    maxTemplates: 'unlimited',
    features: [
      'Clientes ilimitados',
      'Templates ilimitados',
      'Multi-tenant completo',
      'Relatórios executivos',
      'Integrações customizadas',
      'Suporte dedicado 24/7',
      'SLA garantido',
      'Onboarding premium',
      'Consultoria estratégica'
    ]
  }
];

interface PricingSectionProps {
  onGetStarted: (planId?: string) => void;
}

export default function PricingSection({ onGetStarted }: PricingSectionProps) {
  const [isAnnual, setIsAnnual] = useState(false);

  const getPrice = (plan: PricingPlan) => {
    return isAnnual ? plan.annualPrice : plan.monthlyPrice;
  };

  const getSavings = (plan: PricingPlan) => {
    const monthlyTotal = plan.monthlyPrice * 12;
    const savings = monthlyTotal - plan.annualPrice;
    return Math.round((savings / monthlyTotal) * 100);
  };

  return (
    <section className="py-24 px-6 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Escolha o Plano Perfeito
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Comece grátis e escale conforme sua agência cresce. Todos os planos incluem 14 dias de teste gratuito.
          </p>
          
          {/* Toggle anual/mensal */}
          <div className="flex items-center justify-center space-x-4 mb-12">
            <span className={`text-lg ${!isAnnual ? 'text-blue-600 font-semibold' : 'text-gray-600'}`}>
              Mensal
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                isAnnual ? 'bg-blue-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  isAnnual ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-lg ${isAnnual ? 'text-blue-600 font-semibold' : 'text-gray-600'}`}>
              Anual
            </span>
            {isAnnual && (
              <span className="bg-green-100 text-green-800 text-sm px-3 py-1 rounded-full font-medium">
                Economize até 20%
              </span>
            )}
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative bg-white rounded-2xl p-8 transition-all duration-300 hover:scale-105 ${
                plan.recommended
                  ? 'border-2 border-blue-500 shadow-2xl'
                  : 'border border-gray-200 shadow-lg hover:shadow-xl'
              }`}
            >
              {plan.recommended && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-medium">
                    Mais Popular
                  </span>
                </div>
              )}

              <div className="text-center mb-8">
                <div className={`inline-flex p-3 rounded-full mb-4 ${
                  plan.recommended ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                }`}>
                  {plan.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <p className="text-gray-600 mb-4">{plan.description}</p>
                <div className="mb-2">
                  <span className="text-4xl font-bold text-gray-900">
                    R$ {getPrice(plan).toFixed(2).replace('.', ',')}
                  </span>
                  <span className="text-gray-600">/{isAnnual ? 'ano' : 'mês'}</span>
                </div>
                {isAnnual && (
                  <p className="text-green-600 text-sm font-medium">
                    Economize {getSavings(plan)}% no plano anual
                  </p>
                )}
              </div>

              <div className="space-y-4 mb-8">
                <div className="text-sm text-gray-600 mb-3">
                  <span className="font-medium">
                    {typeof plan.maxClients === 'number' ? `${plan.maxClients} clientes` : 'Clientes ilimitados'}
                  </span>
                  {' • '}
                  <span className="font-medium">
                    {typeof plan.maxTemplates === 'number' ? `${plan.maxTemplates} templates` : 'Templates ilimitados'}
                  </span>
                </div>
                {plan.features.map((feature, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => onGetStarted(plan.id)}
                className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-200 ${
                  plan.recommended
                    ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg hover:shadow-xl'
                    : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                }`}
              >
                Começar Teste Grátis
              </button>
            </div>
          ))}
        </div>

        {/* Garantia */}
        <div className="text-center mt-12">
          <p className="text-gray-600">
            💰 <strong>Garantia de 30 dias</strong> - Não gostou? Devolvemos seu dinheiro, sem perguntas.
          </p>
        </div>
      </div>
    </section>
  );
}
