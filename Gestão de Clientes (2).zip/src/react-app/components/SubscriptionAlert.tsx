import { useSubscription } from '@/react-app/hooks/useSubscription';
import { AlertTriangle, Crown, Calendar, CreditCard } from 'lucide-react';
import { useNavigate } from 'react-router';

export default function SubscriptionAlert() {
  const { subscription, isLoading, hasActiveSubscription } = useSubscription();
  const navigate = useNavigate();

  if (isLoading || !subscription) return null;

  const getDaysUntilExpiry = () => {
    if (!subscription.next_billing_date && !subscription.end_date) return null;
    
    const expiryDate = new Date(subscription.next_billing_date || subscription.end_date!);
    const today = new Date();
    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  const daysUntilExpiry = getDaysUntilExpiry();
  const isExpired = subscription.status !== 'active' || (daysUntilExpiry !== null && daysUntilExpiry <= 0);
  const isExpiringSoon = daysUntilExpiry !== null && daysUntilExpiry > 0 && daysUntilExpiry <= 7;

  // Don't show alert if subscription is active and not expiring soon
  if (hasActiveSubscription && !isExpiringSoon && !isExpired) return null;

  return (
    <div className={`border-l-4 p-4 mb-6 rounded-r-lg ${
      isExpired 
        ? 'bg-red-50 border-red-400 text-red-700' 
        : isExpiringSoon 
        ? 'bg-orange-50 border-orange-400 text-orange-700'
        : 'bg-blue-50 border-blue-400 text-blue-700'
    }`}>
      <div className="flex items-start">
        <div className="flex-shrink-0">
          {isExpired ? (
            <AlertTriangle className="h-5 w-5 text-red-400" />
          ) : isExpiringSoon ? (
            <Calendar className="h-5 w-5 text-orange-400" />
          ) : (
            <Crown className="h-5 w-5 text-blue-400" />
          )}
        </div>
        <div className="ml-3 flex-1">
          <h3 className="text-sm font-medium">
            {isExpired 
              ? 'Assinatura Expirada' 
              : isExpiringSoon 
              ? 'Assinatura Expirando em Breve'
              : 'Status da Assinatura'}
          </h3>
          <div className="mt-2 text-sm">
            <p>
              {isExpired ? (
                'Sua assinatura expirou. Renove para continuar usando todos os recursos.'
              ) : isExpiringSoon ? (
                `Sua assinatura expira em ${daysUntilExpiry} ${daysUntilExpiry === 1 ? 'dia' : 'dias'}. Renove antes do vencimento.`
              ) : (
                `Você está no plano ${subscription.plan_name} (${subscription.billing_cycle === 'annual' ? 'Anual' : 'Mensal'})`
              )}
            </p>
            
            {subscription.next_billing_date && (
              <p className="mt-1">
                <Calendar className="inline h-4 w-4 mr-1" />
                Próximo vencimento: {new Date(subscription.next_billing_date).toLocaleDateString('pt-BR')}
              </p>
            )}
            
            <p className="mt-1">
              <CreditCard className="inline h-4 w-4 mr-1" />
              Valor: R$ {subscription.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
          </div>
          
          <div className="mt-4">
            <button
              onClick={() => navigate('/checkout')}
              className={`text-sm font-medium px-4 py-2 rounded-lg transition-colors ${
                isExpired 
                  ? 'bg-red-600 text-white hover:bg-red-700' 
                  : isExpiringSoon 
                  ? 'bg-orange-600 text-white hover:bg-orange-700'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {isExpired ? 'Renovar Agora' : isExpiringSoon ? 'Renovar Assinatura' : 'Ver Planos'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
