import { useState } from 'react';
import { 
  Users, 
  CheckSquare, 
  CreditCard, 
  BarChart3, 
  Zap, 
  Shield
} from 'lucide-react';

const features = [
  {
    id: 'client-management',
    title: 'Gestão Inteligente de Clientes',
    description: 'Organize todos os dados dos seus clientes em um sistema centralizado e intuitivo.',
    icon: <Users className="w-8 h-8" />,
    benefits: [
      'Perfis completos com histórico detalhado',
      'Controle de status e acompanhamento',
      'Informações de contrato e valores',
      'Busca avançada e filtros inteligentes'
    ],
    image: '🧑‍💼'
  },
  {
    id: 'checklist-templates',
    title: 'Templates de Checklist Personalizáveis',
    description: 'Crie e gerencie checklists padronizados para garantir que nenhum passo seja esquecido.',
    icon: <CheckSquare className="w-8 h-8" />,
    benefits: [
      'Templates reutilizáveis e customizáveis',
      'Acompanhamento de progresso em tempo real',
      'Categorização e priorização de tarefas',
      'Histórico completo de implementações'
    ],
    image: '✅'
  },
  {
    id: 'payment-control',
    title: 'Controle Financeiro Completo',
    description: 'Gerencie pagamentos de implementação e mensalidades com total transparência.',
    icon: <CreditCard className="w-8 h-8" />,
    benefits: [
      'Controle de taxas de implementação',
      'Gestão de mensalidades recorrentes',
      'Relatórios financeiros detalhados',
      'Alertas de vencimento automáticos'
    ],
    image: '💰'
  },
  {
    id: 'analytics',
    title: 'Analytics e Relatórios',
    description: 'Tenha insights completos sobre seu negócio com dashboards e relatórios inteligentes.',
    icon: <BarChart3 className="w-8 h-8" />,
    benefits: [
      'Dashboard executivo em tempo real',
      'Métricas de performance e crescimento',
      'Relatórios personalizáveis',
      'Previsões e tendências'
    ],
    image: '📊'
  },
  {
    id: 'automation',
    title: 'Automações Inteligentes',
    description: 'Automatize tarefas repetitivas e foque no que realmente importa: seus clientes.',
    icon: <Zap className="w-8 h-8" />,
    benefits: [
      'Notificações automáticas de vencimento',
      'Lembretes de follow-up',
      'Atualizações de status automáticas',
      'Fluxos de trabalho personalizados'
    ],
    image: '⚡'
  },
  {
    id: 'security',
    title: 'Segurança Enterprise',
    description: 'Seus dados e de seus clientes protegidos com os mais altos padrões de segurança.',
    icon: <Shield className="w-8 h-8" />,
    benefits: [
      'Criptografia end-to-end',
      'Backup automático diário',
      'Autenticação Google OAuth',
      'Conformidade com LGPD'
    ],
    image: '🔒'
  }
];

export default function FeaturesShowcase() {
  const [activeFeature, setActiveFeature] = useState(features[0].id);

  const currentFeature = features.find(f => f.id === activeFeature) || features[0];

  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Funcionalidades Que Transformam
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Descubra como nossa plataforma pode revolucionar a gestão da sua agência de IA e impulsionar seus resultados.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-8 items-start">
          {/* Feature Navigation - Balanced sizing */}
          <div className="lg:col-span-6 space-y-4">
            {features.map((feature) => (
              <button
                key={feature.id}
                onClick={() => setActiveFeature(feature.id)}
                className={`w-full text-left p-4 rounded-xl transition-all duration-300 ${
                  activeFeature === feature.id
                    ? 'bg-blue-50 border-2 border-blue-200 shadow-lg'
                    : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div className={`p-2 rounded-lg flex-shrink-0 ${
                    activeFeature === feature.id
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-200 text-gray-600'
                  }`}>
                    {feature.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base font-semibold text-gray-900 mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 text-sm">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Feature Detail - Wider sizing */}
          <div className="lg:col-span-6 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl p-8 sticky top-8">
            <div className="text-center mb-6">
              <div className="text-8xl mb-4">{currentFeature.image}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {currentFeature.title}
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Organize todos os dados dos seus clientes em um sistema centralizado e intuitivo.
              </p>
            </div>

            <div className="space-y-2">
              {currentFeature.benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="flex items-start space-x-2 animate-fade-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center mt-0.5 flex-shrink-0">
                    <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-700 text-sm font-medium">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-20 grid md:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">3x</div>
            <div className="text-gray-600">Potencial de Crescimento</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">70%</div>
            <div className="text-gray-600">Redução no Tempo de Gestão</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">99.9%</div>
            <div className="text-gray-600">Confiabilidade</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">24/7</div>
            <div className="text-gray-600">Disponibilidade</div>
          </div>
        </div>
      </div>
    </section>
  );
}
