import { useAuth } from '@getmocha/users-service/react';
import { useNavigate, useLocation } from 'react-router';
import { 
  Users, 
  CheckSquare, 
  CreditCard, 
  LayoutDashboard, 
  LogOut,
  Menu,
  X,
  FolderOpen,
  BarChart3,
  UserCog,
  User,
  Code
} from 'lucide-react';
import { useState } from 'react';
import SubscriptionAlert from '@/react-app/components/SubscriptionAlert';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const menuItems = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/clients', label: 'Clientes', icon: Users },
    { path: '/checklists', label: 'Checklists', icon: CheckSquare },
    { path: '/developers', label: 'Desenvolvedores', icon: Code },
    { path: '/projects', label: 'Projetos', icon: FolderOpen },
    { path: '/payments', label: 'Pagamentos', icon: CreditCard },
    { path: '/reports', label: 'Relatórios', icon: BarChart3 },
    { path: '/subscribers', label: 'Assinantes', icon: UserCog },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-blue-200 px-6 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-blue-50"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            
            <div className="flex items-center space-x-6">
              <img 
                src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
                alt="DIA Solutions AI" 
                className="h-32 w-auto"
              />
              <span className="font-bold text-gray-800 text-xl">DIA Solutions AI</span>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/profile')}
              className="flex items-center space-x-3 px-3 py-2 text-sm text-gray-700 hover:bg-blue-50 rounded-lg transition-colors"
            >
              {user?.google_user_data.picture ? (
                <img
                  src={user.google_user_data.picture}
                  alt={user.google_user_data.name || user.email}
                  className="w-8 h-8 rounded-full"
                />
              ) : (
                <User className="w-4 h-4" />
              )}
              <span className="hidden sm:inline">
                {user?.google_user_data.name || user?.email}
              </span>
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sair</span>
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`bg-white/90 backdrop-blur-lg border-r border-blue-200 w-64 min-h-[calc(100vh-97px)] ${
          isMobileMenuOpen ? 'block' : 'hidden md:block'
        }`}>
          <nav className="p-4">
            <ul className="space-y-2">
              {menuItems.map(({ path, label, icon: Icon }) => (
                <li key={path}>
                  <button
                    onClick={() => {
                      navigate(path);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      location.pathname === path
                        ? 'bg-blue-100 text-blue-700 border border-blue-300'
                        : 'text-gray-700 hover:bg-blue-50'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 p-6">
          <SubscriptionAlert />
          {children}
        </main>
      </div>

      {/* Mobile menu overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-10 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </div>
  );
}
