import { useState } from 'react';
import { Play, X, ChevronLeft, ChevronRight } from 'lucide-react';

const demoSlides = [
  {
    title: 'Dashboard Principal',
    description: 'Visão geral completa dos seus clientes, receitas e métricas importantes em tempo real.',
    image: 'https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/demo-dashboard.jpg'
  },
  {
    title: 'Gestão de Clientes',
    description: 'Organize todos os dados dos clientes de forma centralizada com status e informações detalhadas.',
    image: 'https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/demo-clients.jpg'
  },
  {
    title: 'Checklists e Processos',
    description: 'Templates padronizados garantem que nenhum passo seja esquecido na implementação.',
    image: 'https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/demo-checklist.jpg'
  },
  {
    title: 'Controle Financeiro',
    description: 'Gerencie pagamentos, faturas e receitas com transparência total e relatórios detalhados.',
    image: 'https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/demo-payments.jpg'
  }
];

export default function DemoVideo() {
  const [showModal, setShowModal] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % demoSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + demoSlides.length) % demoSlides.length);
  };

  const openDemo = () => {
    setShowModal(true);
    setCurrentSlide(0);
  };

  return (
    <>
      <button
        onClick={openDemo}
        className="inline-flex items-center space-x-3 bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all duration-300 shadow-lg border border-gray-200"
      >
        <Play className="w-5 h-5" />
        <span>Ver Demo Interativo</span>
      </button>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b">
              <h3 className="text-2xl font-bold text-gray-900">
                Demo Interativo - {demoSlides[currentSlide].title}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="relative">
              {/* Slide Image */}
              <div className="relative h-96 bg-gray-100 overflow-hidden">
                <img
                  src={demoSlides[currentSlide].image}
                  alt={demoSlides[currentSlide].title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    const nextElement = e.currentTarget.nextElementSibling as HTMLElement;
                    if (nextElement) {
                      nextElement.style.display = 'flex';
                    }
                  }}
                />
                <div 
                  className="hidden absolute inset-0 bg-gradient-to-br from-blue-100 to-indigo-100 items-center justify-center"
                  style={{ display: 'none' }}
                >
                  <div className="text-center">
                    <div className="text-6xl mb-4">📊</div>
                    <h4 className="text-2xl font-bold text-gray-900 mb-2">
                      {demoSlides[currentSlide].title}
                    </h4>
                    <p className="text-gray-600 max-w-md">
                      {demoSlides[currentSlide].description}
                    </p>
                  </div>
                </div>
              </div>

              {/* Navigation Arrows */}
              <button
                onClick={prevSlide}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full p-3 shadow-lg transition-all duration-200"
              >
                <ChevronLeft className="w-6 h-6 text-gray-700" />
              </button>
              <button
                onClick={nextSlide}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full p-3 shadow-lg transition-all duration-200"
              >
                <ChevronRight className="w-6 h-6 text-gray-700" />
              </button>
            </div>

            <div className="p-6">
              {/* Slide Description */}
              <div className="text-center mb-6">
                <h4 className="text-xl font-bold text-gray-900 mb-2">
                  {demoSlides[currentSlide].title}
                </h4>
                <p className="text-gray-600">
                  {demoSlides[currentSlide].description}
                </p>
              </div>

              {/* Slide Indicators */}
              <div className="flex justify-center space-x-2 mb-6">
                {demoSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentSlide
                        ? 'bg-blue-600'
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentSlide + 1) / demoSlides.length) * 100}%` }}
                />
              </div>

              {/* Auto-advance controls */}
              <div className="text-center">
                <p className="text-gray-600 mb-4">
                  {currentSlide + 1} de {demoSlides.length} - Use as setas ou clique nos indicadores para navegar
                </p>
                <button
                  onClick={() => setShowModal(false)}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                >
                  Começar Teste Grátis
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
