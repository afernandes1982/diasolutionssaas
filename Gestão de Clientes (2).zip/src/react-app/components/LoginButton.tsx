import { LogIn } from 'lucide-react';

interface LoginButtonProps {
  onClick: () => void;
  size?: 'normal' | 'large';
}

export default function LoginButton({ onClick, size = 'normal' }: LoginButtonProps) {
  const baseClasses = "inline-flex items-center gap-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl";
  const sizeClasses = size === 'large' 
    ? "px-8 py-4 text-lg" 
    : "px-6 py-3 text-base";

  return (
    <button
      onClick={onClick}
      className={`${baseClasses} ${sizeClasses}`}
    >
      <LogIn className={size === 'large' ? "w-6 h-6" : "w-5 h-5"} />
      Entrar com Google
    </button>
  );
}
