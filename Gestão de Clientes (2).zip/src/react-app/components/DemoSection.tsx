import { useState } from 'react';
import { Play, X, Users, CheckSquare, CreditCard } from 'lucide-react';

const mockData = {
  clients: [
    { name: 'TechCorp Ltda', status: 'Ativo', revenue: 'R$ 2.500/mês' },
    { name: 'InnovateAI', status: 'Implementação', revenue: 'R$ 1.800/mês' },
    { name: 'SmartBot Solutions', status: 'Ativo', revenue: 'R$ 3.200/mês' },
  ],
  tasks: [
    { task: 'Configurar GPT-4 API', status: 'Concluído' },
    { task: 'Setup servidor n8n', status: 'Concluído' },
    { task: 'Treinar modelo personalizado', status: 'Em progresso' },
    { task: 'Testes de integração WhatsApp', status: 'Pendente' },
  ],
  payments: [
    { client: 'TechCorp Ltda', amount: 'R$ 2.500', status: 'Pago', date: '15/07/2024' },
    { client: 'InnovateAI', amount: 'R$ 1.800', status: 'Pendente', date: '20/07/2024' },
    { client: 'SmartBot Solutions', amount: 'R$ 3.200', status: 'Pago', date: '10/07/2024' },
  ]
};

export default function DemoSection() {
  const [showModal, setShowModal] = useState(false);
  const [activeTab, setActiveTab] = useState('clients');

  const renderTabContent = () => {
    switch (activeTab) {
      case 'clients':
        return (
          <div className="space-y-3">
            {mockData.clients.map((client, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900">{client.name}</div>
                  <div className="text-sm text-gray-600">{client.revenue}</div>
                </div>
                <span className={`px-2 py-1 text-xs rounded-full ${
                  client.status === 'Ativo' 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {client.status}
                </span>
              </div>
            ))}
          </div>
        );
      case 'tasks':
        return (
          <div className="space-y-3">
            {mockData.tasks.map((task, index) => (
              <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-4 h-4 rounded-full ${
                  task.status === 'Concluído' ? 'bg-green-500' :
                  task.status === 'Em progresso' ? 'bg-yellow-500' : 'bg-gray-300'
                }`} />
                <div>
                  <div className="font-medium text-gray-900">{task.task}</div>
                  <div className="text-sm text-gray-600">{task.status}</div>
                </div>
              </div>
            ))}
          </div>
        );
      case 'payments':
        return (
          <div className="space-y-3">
            {mockData.payments.map((payment, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900">{payment.client}</div>
                  <div className="text-sm text-gray-600">{payment.date}</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-gray-900">{payment.amount}</div>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    payment.status === 'Pago' 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {payment.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <section className="py-24 px-6 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Veja o Sistema em Ação
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Uma demonstração interativa de como nossa plataforma pode transformar a gestão da sua agência de IA.
          </p>
          <button
            onClick={() => setShowModal(true)}
            className="inline-flex items-center space-x-3 bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            <Play className="w-6 h-6" />
            <span>Ver Demo Interativa</span>
          </button>
        </div>

        {/* Preview Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Gestão de Clientes</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Visualize todos os seus clientes, contratos e status em uma interface limpa e organizada.
            </p>
            <div className="text-2xl font-bold text-blue-600">500+ Clientes</div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckSquare className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Checklists</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Templates padronizados garantem que nenhum passo seja esquecido na implementação.
            </p>
            <div className="text-2xl font-bold text-green-600">95% Eficiência</div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-purple-100 rounded-lg">
                <CreditCard className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Pagamentos</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Controle completo de receitas, faturas e cobrancas em um só lugar.
            </p>
            <div className="text-2xl font-bold text-purple-600">R$ 2.5M+</div>
          </div>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">⚡</span>
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">3x Mais Rápido</h4>
            <p className="text-gray-600 text-sm">Reduza o tempo de gestão em até 70%</p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">💰</span>
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">ROI Garantido</h4>
            <p className="text-gray-600 text-sm">Retorno sobre investimento em 30 dias</p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🎯</span>
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">Zero Erros</h4>
            <p className="text-gray-600 text-sm">Processos padronizados e checados</p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">📈</span>
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">Crescimento</h4>
            <p className="text-gray-600 text-sm">Escale sem perder qualidade</p>
          </div>
        </div>
      </div>

      {/* Demo Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b">
              <h3 className="text-2xl font-bold text-gray-900">Demo Interativa - DIA Solutions AI</h3>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6">
              {/* Tab Navigation */}
              <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg">
                <button
                  onClick={() => setActiveTab('clients')}
                  className={`flex-1 flex items-center justify-center space-x-2 py-2 px-4 rounded-md transition-colors ${
                    activeTab === 'clients'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  <span>Clientes</span>
                </button>
                <button
                  onClick={() => setActiveTab('tasks')}
                  className={`flex-1 flex items-center justify-center space-x-2 py-2 px-4 rounded-md transition-colors ${
                    activeTab === 'tasks'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <CheckSquare className="w-4 h-4" />
                  <span>Checklists</span>
                </button>
                <button
                  onClick={() => setActiveTab('payments')}
                  className={`flex-1 flex items-center justify-center space-x-2 py-2 px-4 rounded-md transition-colors ${
                    activeTab === 'payments'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Pagamentos</span>
                </button>
              </div>

              {/* Tab Content */}
              <div className="min-h-[300px]">
                {renderTabContent()}
              </div>

              <div className="mt-8 text-center">
                <p className="text-gray-600 mb-4">
                  Esta é apenas uma prévia das funcionalidades. O sistema completo oferece muito mais!
                </p>
                <button
                  onClick={() => setShowModal(false)}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                >
                  Começar Teste Grátis
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
