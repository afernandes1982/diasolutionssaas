import { useState } from 'react';
import { X } from 'lucide-react';
import type { ClientType, ChecklistTemplateType } from '@/shared/types';

interface ClientChecklistFormProps {
  clients: ClientType[];
  templates: ChecklistTemplateType[];
  onSubmit: (data: { client_id: number; checklist_template_id: number; name?: string }) => void;
  onCancel: () => void;
}

export default function ClientChecklistForm({ clients, templates, onSubmit, onCancel }: ClientChecklistFormProps) {
  const [formData, setFormData] = useState({
    client_id: '',
    checklist_template_id: '',
    name: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const selectedTemplate = templates.find(t => t.id === parseInt(formData.checklist_template_id));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors: Record<string, string> = {};
    
    if (!formData.client_id) {
      newErrors.client_id = 'Cliente é obrigatório';
    }
    
    if (!formData.checklist_template_id) {
      newErrors.checklist_template_id = 'Template é obrigatório';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const submitData = {
      client_id: parseInt(formData.client_id),
      checklist_template_id: parseInt(formData.checklist_template_id),
      name: formData.name.trim() || undefined,
    };

    onSubmit(submitData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Novo Checklist</h2>
          <button
            onClick={onCancel}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Cliente */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cliente *
            </label>
            <select
              value={formData.client_id}
              onChange={(e) => setFormData({ ...formData, client_id: e.target.value })}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent ${
                errors.client_id ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Selecione um cliente</option>
              {clients.map((client) => (
                <option key={client.id} value={client.id}>
                  {client.name} {client.company && `(${client.company})`}
                </option>
              ))}
            </select>
            {errors.client_id && <p className="mt-1 text-sm text-red-600">{errors.client_id}</p>}
          </div>

          {/* Template */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Template *
            </label>
            <select
              value={formData.checklist_template_id}
              onChange={(e) => setFormData({ ...formData, checklist_template_id: e.target.value })}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent ${
                errors.checklist_template_id ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Selecione um template</option>
              {templates
                .sort((a, b) => {
                  // Colocar templates padrão primeiro
                  if (a.is_default && !b.is_default) return -1;
                  if (!a.is_default && b.is_default) return 1;
                  return a.name.localeCompare(b.name);
                })
                .map((template) => (
                <option key={template.id} value={template.id}>
                  {template.is_default ? '✨ ' : ''}{template.name}
                  {template.is_default ? ' (Padrão)' : ''}
                </option>
              ))}
            </select>
            {errors.checklist_template_id && <p className="mt-1 text-sm text-red-600">{errors.checklist_template_id}</p>}
          </div>

          {/* Nome personalizado */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nome do Checklist (opcional)
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder={selectedTemplate ? `${selectedTemplate.name}` : "Nome personalizado para o checklist"}
            />
            <p className="mt-1 text-xs text-gray-500">
              Se não informado, será usado o nome do template
            </p>
          </div>

          {/* Template Info */}
          {selectedTemplate && (
            <div className="bg-gray-50 p-3 rounded-lg">
              <h4 className="text-sm font-medium text-gray-900 mb-1">Template Selecionado:</h4>
              <p className="text-sm text-gray-600">{selectedTemplate.name}</p>
              {selectedTemplate.description && (
                <p className="text-xs text-gray-500 mt-1">{selectedTemplate.description}</p>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              Criar Checklist
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
