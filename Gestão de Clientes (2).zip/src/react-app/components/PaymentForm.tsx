import { useState } from 'react';
import { X, Send } from 'lucide-react';
import type { ClientType, CreatePaymentType } from '@/shared/types';

interface PaymentFormProps {
  clients: ClientType[];
  onSubmit: (data: CreatePaymentType) => void;
  onCancel: () => void;
}

export default function PaymentForm({ clients, onSubmit, onCancel }: PaymentFormProps) {
  const [formData, setFormData] = useState({
    client_id: '',
    type: 'one_time' as 'one_time' | 'recurring' | 'implementation' | 'monthly',
    amount: '',
    due_date: '',
    payment_method: '',
    notes: '',
    invoice_number: '',
    send_to_asaas: false,
    billing_type: 'UNDEFINED' as 'BOLETO' | 'CREDIT_CARD' | 'PIX' | 'UNDEFINED',
    end_date: '',
    installment_count: '',
    schedule_option: 'single' as 'single' | 'end_date' | 'installments',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors: Record<string, string> = {};
    
    if (!formData.client_id) {
      newErrors.client_id = 'Cliente é obrigatório';
    }
    
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Valor deve ser maior que 0';
    }
    
    if (!formData.due_date) {
      newErrors.due_date = 'Data de vencimento é obrigatória';
    }

    if (formData.send_to_asaas && formData.billing_type === 'UNDEFINED') {
      newErrors.billing_type = 'Tipo de cobrança é obrigatório para envio ao Asaas';
    }

    // Validação específica para parcelamento
    if (formData.schedule_option === 'end_date' && !formData.end_date) {
      newErrors.end_date = 'Data final é obrigatória';
    }

    if (formData.schedule_option === 'installments') {
      if (!formData.installment_count || parseInt(formData.installment_count) <= 0) {
        newErrors.installment_count = 'Número de parcelas deve ser maior que 0';
      }
    }

    // Validar se data final é posterior à data de vencimento
    if (formData.schedule_option === 'end_date' && formData.end_date && formData.due_date) {
      if (new Date(formData.end_date) <= new Date(formData.due_date)) {
        newErrors.end_date = 'Data final deve ser posterior à data de vencimento';
      }
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const submitData: CreatePaymentType = {
      client_id: parseInt(formData.client_id),
      type: formData.type,
      amount: parseFloat(formData.amount),
      due_date: formData.due_date,
      payment_method: formData.payment_method.trim() || undefined,
      notes: formData.notes.trim() || undefined,
      invoice_number: formData.invoice_number.trim() || undefined,
      send_to_asaas: formData.send_to_asaas,
      billing_type: formData.send_to_asaas ? formData.billing_type : undefined,
      end_date: formData.schedule_option === 'end_date' ? formData.end_date : undefined,
      installment_count: formData.schedule_option === 'installments' ? parseInt(formData.installment_count) : undefined,
    };

    onSubmit(submitData);
  };

  const showSchedulingOptions = formData.type === 'recurring' || formData.type === 'monthly';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Novo Pagamento</h2>
          <button
            onClick={onCancel}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Cliente */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cliente *
            </label>
            <select
              value={formData.client_id}
              onChange={(e) => setFormData({ ...formData, client_id: e.target.value })}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.client_id ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Selecione um cliente</option>
              {clients.map((client) => (
                <option key={client.id} value={client.id}>
                  {client.name}
                </option>
              ))}
            </select>
            {errors.client_id && <p className="mt-1 text-sm text-red-600">{errors.client_id}</p>}
          </div>

          {/* Tipo */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tipo *
            </label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value as any, schedule_option: 'single' })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="implementation">Taxa de Implementação</option>
              <option value="recurring">Cobrança Recorrente</option>
              <option value="monthly">Mensalidade</option>
              <option value="one_time">Pagamento Único</option>
            </select>
          </div>

          {/* Valor */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Valor (R$) *
            </label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.amount ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="0.00"
            />
            {errors.amount && <p className="mt-1 text-sm text-red-600">{errors.amount}</p>}
          </div>

          {/* Data de vencimento */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {showSchedulingOptions ? 'Data do Primeiro Vencimento *' : 'Data de Vencimento *'}
            </label>
            <input
              type="date"
              value={formData.due_date}
              onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.due_date ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.due_date && <p className="mt-1 text-sm text-red-600">{errors.due_date}</p>}
          </div>

          {/* Opções de Agendamento - Só aparece para recurring/monthly */}
          {showSchedulingOptions && (
            <div className="border border-purple-200 rounded-lg p-4 bg-purple-50">
              <label className="block text-sm font-medium text-purple-900 mb-3">
                Configuração do Período
              </label>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    id="single"
                    name="schedule_option"
                    value="single"
                    checked={formData.schedule_option === 'single'}
                    onChange={(e) => setFormData({ ...formData, schedule_option: e.target.value as any })}
                    className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 focus:ring-purple-500"
                  />
                  <label htmlFor="single" className="text-sm text-purple-900">
                    Cobrança única (sem data limite)
                  </label>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    id="end_date"
                    name="schedule_option"
                    value="end_date"
                    checked={formData.schedule_option === 'end_date'}
                    onChange={(e) => setFormData({ ...formData, schedule_option: e.target.value as any })}
                    className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 focus:ring-purple-500"
                  />
                  <label htmlFor="end_date" className="text-sm text-purple-900">
                    Definir data final
                  </label>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    id="installments"
                    name="schedule_option"
                    value="installments"
                    checked={formData.schedule_option === 'installments'}
                    onChange={(e) => setFormData({ ...formData, schedule_option: e.target.value as any })}
                    className="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 focus:ring-purple-500"
                  />
                  <label htmlFor="installments" className="text-sm text-purple-900">
                    Definir número de parcelas
                  </label>
                </div>
              </div>

              {/* Data final */}
              {formData.schedule_option === 'end_date' && (
                <div className="mt-4">
                  <label className="block text-xs font-medium text-purple-700 mb-2">
                    Data Final *
                  </label>
                  <input
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm ${
                      errors.end_date ? 'border-red-500' : 'border-purple-300'
                    }`}
                  />
                  {errors.end_date && <p className="mt-1 text-xs text-red-600">{errors.end_date}</p>}
                </div>
              )}

              {/* Número de parcelas */}
              {formData.schedule_option === 'installments' && (
                <div className="mt-4">
                  <label className="block text-xs font-medium text-purple-700 mb-2">
                    Número de Parcelas *
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formData.installment_count}
                    onChange={(e) => setFormData({ ...formData, installment_count: e.target.value })}
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm ${
                      errors.installment_count ? 'border-red-500' : 'border-purple-300'
                    }`}
                    placeholder="Ex: 12"
                  />
                  {errors.installment_count && <p className="mt-1 text-xs text-red-600">{errors.installment_count}</p>}
                </div>
              )}
            </div>
          )}

          {/* Enviar para Asaas */}
          <div className="border border-blue-200 rounded-lg p-4 bg-blue-50">
            <div className="flex items-center gap-3 mb-3">
              <input
                type="checkbox"
                id="send_to_asaas"
                checked={formData.send_to_asaas}
                onChange={(e) => setFormData({ ...formData, send_to_asaas: e.target.checked })}
                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
              />
              <label htmlFor="send_to_asaas" className="flex items-center gap-2 text-sm font-medium text-blue-900">
                <Send className="w-4 h-4" />
                Enviar cobrança para Asaas
              </label>
            </div>
            
            {formData.send_to_asaas && (
              <div>
                <label className="block text-sm font-medium text-blue-700 mb-2">
                  Tipo de Cobrança *
                </label>
                <select
                  value={formData.billing_type}
                  onChange={(e) => setFormData({ ...formData, billing_type: e.target.value as any })}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    errors.billing_type ? 'border-red-500' : 'border-blue-300'
                  }`}
                >
                  <option value="UNDEFINED">Não definido (cliente escolhe)</option>
                  <option value="BOLETO">Boleto Bancário</option>
                  <option value="CREDIT_CARD">Cartão de Crédito</option>
                  <option value="PIX">PIX</option>
                </select>
                {errors.billing_type && <p className="mt-1 text-sm text-red-600">{errors.billing_type}</p>}
              </div>
            )}
          </div>

          {/* Método de pagamento */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Método de Pagamento (Local)
            </label>
            <input
              type="text"
              value={formData.payment_method}
              onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="PIX, Cartão, Boleto, etc."
            />
          </div>

          {/* Número da fatura */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Número da Fatura
            </label>
            <input
              type="text"
              value={formData.invoice_number}
              onChange={(e) => setFormData({ ...formData, invoice_number: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Ex: INV-2025-001"
            />
          </div>

          {/* Observações */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Observações
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Informações adicionais sobre o pagamento"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
            >
              {formData.send_to_asaas && <Send className="w-4 h-4" />}
              Criar Pagamento
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
