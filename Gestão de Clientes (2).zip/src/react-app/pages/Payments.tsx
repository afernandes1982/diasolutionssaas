import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import Layout from '@/react-app/components/Layout';
import PaymentForm from '@/react-app/components/PaymentForm';
import { Plus, Search, Trash2, CheckCircle, Clock, DollarSign, RefreshCw, ExternalLink } from 'lucide-react';
import type { PaymentType, CreatePaymentType, ClientType } from '@/shared/types';

interface PaymentWithClient extends PaymentType {
  client_name?: string;
}

export default function Payments() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [payments, setPayments] = useState<PaymentWithClient[]>([]);
  const [clients, setClients] = useState<ClientType[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'paid' | 'pending'>('all');

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      const [paymentsRes, clientsRes] = await Promise.all([
        fetch('/api/payments'),
        fetch('/api/clients'),
      ]);
      
      const paymentsData = await paymentsRes.json();
      const clientsData = await clientsRes.json();
      
      setPayments(paymentsData);
      setClients(clientsData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePayment = async (data: CreatePaymentType) => {
    try {
      const response = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        const newPayment = await response.json();
        const client = clients.find(c => c.id === newPayment.client_id);
        const paymentWithClient = {
          ...newPayment,
          client_name: client?.name
        };
        setPayments([paymentWithClient, ...payments]);
        setShowForm(false);
      }
    } catch (error) {
      console.error('Erro ao criar pagamento:', error);
    }
  };

  const handleMarkAsPaid = async (paymentId: number) => {
    try {
      const response = await fetch(`/api/payments/${paymentId}/mark-paid`, {
        method: 'PATCH',
      });

      if (response.ok) {
        setPayments(payments.map(p => 
          p.id === paymentId 
            ? { ...p, is_paid: true, paid_date: new Date().toISOString().split('T')[0] }
            : p
        ));
      }
    } catch (error) {
      console.error('Erro ao marcar como pago:', error);
    }
  };

  const handleDeletePayment = async (paymentId: number) => {
    if (!confirm('Tem certeza que deseja excluir este pagamento?')) return;

    try {
      const response = await fetch(`/api/payments/${paymentId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setPayments(payments.filter(p => p.id !== paymentId));
      }
    } catch (error) {
      console.error('Erro ao excluir pagamento:', error);
    }
  };

  const handleSyncAsaas = async (paymentId: number) => {
    try {
      const response = await fetch(`/api/payments/${paymentId}/sync-asaas`, {
        method: 'POST',
      });

      if (response.ok) {
        const updatedPayment = await response.json();
        setPayments(payments.map(p => 
          p.id === paymentId ? { ...p, ...updatedPayment } : p
        ));
      }
    } catch (error) {
      console.error('Erro ao sincronizar com Asaas:', error);
    }
  };

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = payment.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || 
      (filterStatus === 'paid' && payment.is_paid) ||
      (filterStatus === 'pending' && !payment.is_paid);

    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: payments.reduce((sum, p) => sum + p.amount, 0),
    paid: payments.filter(p => p.is_paid).reduce((sum, p) => sum + p.amount, 0),
    pending: payments.filter(p => !p.is_paid).reduce((sum, p) => sum + p.amount, 0),
  };

  if (isPending || loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Pagamentos</h1>
            <p className="text-gray-600">Controle financeiro dos seus clientes</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Novo Pagamento
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  R$ {stats.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-blue-500 text-white">
                <DollarSign className="w-6 h-6" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Recebido</p>
                <p className="text-2xl font-bold text-green-600 mt-1">
                  R$ {stats.paid.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-green-500 text-white">
                <CheckCircle className="w-6 h-6" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pendente</p>
                <p className="text-2xl font-bold text-orange-600 mt-1">
                  R$ {stats.pending.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-orange-500 text-white">
                <Clock className="w-6 h-6" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar por cliente ou número da fatura..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as 'all' | 'paid' | 'pending')}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            <option value="all">Todos</option>
            <option value="paid">Pagos</option>
            <option value="pending">Pendentes</option>
          </select>
        </div>

        {/* Payments Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cliente
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Tipo
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Valor
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Vencimento
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredPayments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {payment.client_name}
                        </div>
                        {payment.invoice_number && (
                          <div className="text-sm text-gray-500">
                            Fatura: {payment.invoice_number}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        payment.type === 'implementation' 
                          ? 'bg-blue-100 text-blue-700' 
                          : payment.type === 'recurring'
                          ? 'bg-purple-100 text-purple-700'
                          : payment.type === 'monthly'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}>
                        {payment.type === 'implementation' ? 'Implementação' : 
                         payment.type === 'recurring' ? 'Recorrente' :
                         payment.type === 'monthly' ? 'Mensalidade' : 'Único'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      R$ {payment.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(payment.due_date).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col gap-1">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          payment.is_paid 
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-red-100 text-red-700'
                        }`}>
                          {payment.is_paid ? 'Pago' : 'Pendente'}
                        </span>
                        {payment.send_to_asaas && (
                          <div className="flex items-center gap-1">
                            <ExternalLink className="w-3 h-3 text-blue-500" />
                            <span className="text-xs text-blue-600">
                              {payment.asaas_status || 'Enviado'}
                            </span>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end gap-2">
                        {payment.send_to_asaas && payment.asaas_payment_id && (
                          <button
                            onClick={() => handleSyncAsaas(payment.id)}
                            className="text-blue-600 hover:text-blue-900 hover:bg-blue-50 p-2 rounded-lg transition-colors"
                            title="Sincronizar com Asaas"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </button>
                        )}
                        {!payment.is_paid && (
                          <button
                            onClick={() => handleMarkAsPaid(payment.id)}
                            className="text-green-600 hover:text-green-900 hover:bg-green-50 p-2 rounded-lg transition-colors"
                            title="Marcar como pago"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDeletePayment(payment.id)}
                          className="text-red-600 hover:text-red-900 hover:bg-red-50 p-2 rounded-lg transition-colors"
                          title="Excluir"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredPayments.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">
                {searchTerm || filterStatus !== 'all' 
                  ? 'Nenhum pagamento encontrado' 
                  : 'Nenhum pagamento cadastrado'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Payment Form Modal */}
      {showForm && (
        <PaymentForm
          clients={clients}
          onSubmit={handleCreatePayment}
          onCancel={() => setShowForm(false)}
        />
      )}
    </Layout>
  );
}
