import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { useAuth } from '@getmocha/users-service/react';
import { 
  Check, 
  Star, 
  Zap, 
  Crown, 
  Rocket, 
  CreditCard,
  Shield,
  ArrowLeft,
  Loader2
} from 'lucide-react';
import StripePaymentForm from '@/react-app/components/StripePaymentForm';

interface Plan {
  id: string;
  name: string;
  icon: React.ReactNode;
  monthlyPrice: number;
  annualPrice: number;
  description: string;
  features: string[];
  recommended?: boolean;
  maxClients: number | 'unlimited';
  maxTemplates: number | 'unlimited';
}

const plans: Plan[] = [
  {
    id: 'starter',
    name: 'Starter',
    icon: <Star className="w-6 h-6" />,
    monthlyPrice: 19.90,
    annualPrice: 199,
    description: 'Perfeito para agências iniciantes',
    maxClients: 20,
    maxTemplates: 3,
    features: [
      'Até 20 clientes',
      '3 templates de checklist',
      'Controle de pagamentos',
      'Dashboard básico',
      'Suporte por email',
      'Relatórios mensais'
    ]
  },
  {
    id: 'professional',
    name: 'Professional',
    icon: <Zap className="w-6 h-6" />,
    monthlyPrice: 39.90,
    annualPrice: 399,
    description: 'Ideal para agências em crescimento',
    recommended: true,
    maxClients: 100,
    maxTemplates: 10,
    features: [
      'Até 100 clientes',
      '10 templates de checklist',
      'Controle avançado de pagamentos',
      'Dashboard completo com métricas',
      'Relatórios personalizados',
      'Suporte prioritário',
      'Automações básicas',
      'Backup automático'
    ]
  },
  {
    id: 'business',
    name: 'Business',
    icon: <Crown className="w-6 h-6" />,
    monthlyPrice: 59.90,
    annualPrice: 599,
    description: 'Para agências estabelecidas',
    maxClients: 500,
    maxTemplates: 'unlimited',
    features: [
      'Até 500 clientes',
      'Templates ilimitados',
      'Gestão multi-usuário',
      'Analytics avançados',
      'API para integrações',
      'White-label disponível',
      'Suporte telefônico',
      'Treinamento personalizado'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    icon: <Rocket className="w-6 h-6" />,
    monthlyPrice: 99.90,
    annualPrice: 999,
    description: 'Solução completa para grandes agências',
    maxClients: 'unlimited',
    maxTemplates: 'unlimited',
    features: [
      'Clientes ilimitados',
      'Templates ilimitados',
      'Multi-tenant completo',
      'Relatórios executivos',
      'Integrações customizadas',
      'Suporte dedicado 24/7',
      'SLA garantido',
      'Onboarding premium',
      'Consultoria estratégica'
    ]
  }
];

export default function Checkout() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'credit_card' | 'pix' | 'boleto' | 'stripe'>('stripe');
  const [stripeClientSecret, setStripeClientSecret] = useState<string | null>(null);
  const [stripePublishableKey, setStripePublishableKey] = useState<string | null>(null);

  useEffect(() => {
    const planId = searchParams.get('plan');
    const cycle = searchParams.get('cycle') as 'monthly' | 'annual';
    
    if (planId) {
      const plan = plans.find(p => p.id === planId);
      if (plan) {
        setSelectedPlan(plan);
      }
    }
    
    if (cycle) {
      setBillingCycle(cycle);
    }
  }, [searchParams]);

  if (!user) {
    navigate('/');
    return null;
  }

  const getPrice = (plan: Plan) => {
    return billingCycle === 'annual' ? plan.annualPrice : plan.monthlyPrice;
  };

  const getSavings = (plan: Plan) => {
    const monthlyTotal = plan.monthlyPrice * 12;
    const savings = monthlyTotal - plan.annualPrice;
    return Math.round((savings / monthlyTotal) * 100);
  };

  const handlePlanSelect = (plan: Plan) => {
    setSelectedPlan(plan);
  };

  const handleCheckout = async () => {
    if (!selectedPlan) return;

    setIsProcessing(true);

    try {
      const response = await fetch('/api/subscriptions/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          planId: selectedPlan.id,
          billingCycle,
          paymentMethod,
          amount: getPrice(selectedPlan),
        }),
      });

      if (response.ok) {
        const data = await response.json();
        
        // If Stripe, store the client secret for the form
        if (paymentMethod === 'stripe' && data.stripe_client_secret) {
          setStripeClientSecret(data.stripe_client_secret);
          setStripePublishableKey(data.stripe_publishable_key);
        } else {
          navigate(`/checkout/success?subscription=${data.subscriptionId}`);
        }
      } else {
        throw new Error('Checkout failed');
      }
    } catch (error) {
      console.error('Checkout error:', error);
      alert('Erro no checkout. Tente novamente.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-blue-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/dashboard')}
              className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Voltar</span>
            </button>
            <div className="h-6 w-px bg-gray-300" />
            <div className="flex items-center space-x-3">
              <img 
                src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
                alt="DIA Solutions AI" 
                className="h-10 w-auto"
              />
              <span className="font-bold text-gray-800 text-lg">Checkout</span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            {user?.google_user_data.picture && (
              <img
                src={user.google_user_data.picture}
                alt={user.google_user_data.name || user.email}
                className="w-8 h-8 rounded-full"
              />
            )}
            <span className="text-sm text-gray-700">
              {user?.google_user_data.name || user?.email}
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Escolha Seu Plano
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Comece sua jornada para transformar sua agência de IA
          </p>
          
          {/* Toggle anual/mensal */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className={`text-lg ${billingCycle === 'monthly' ? 'text-blue-600 font-semibold' : 'text-gray-600'}`}>
              Mensal
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                billingCycle === 'annual' ? 'bg-blue-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  billingCycle === 'annual' ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-lg ${billingCycle === 'annual' ? 'text-blue-600 font-semibold' : 'text-gray-600'}`}>
              Anual
            </span>
            {billingCycle === 'annual' && (
              <span className="bg-green-100 text-green-800 text-sm px-3 py-1 rounded-full font-medium">
                Economize até 20%
              </span>
            )}
          </div>
        </div>

        {!selectedPlan ? (
          // Plan Selection
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className={`relative bg-white rounded-2xl p-6 cursor-pointer transition-all duration-300 hover:scale-105 ${
                  plan.recommended
                    ? 'border-2 border-blue-500 shadow-xl'
                    : 'border border-gray-200 shadow-lg hover:shadow-xl'
                }`}
                onClick={() => handlePlanSelect(plan)}
              >
                {plan.recommended && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                      Mais Popular
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <div className={`inline-flex p-3 rounded-full mb-4 ${
                    plan.recommended ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {plan.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-4">{plan.description}</p>
                  <div className="mb-2">
                    <span className="text-3xl font-bold text-gray-900">
                      R$ {getPrice(plan).toFixed(2).replace('.', ',')}
                    </span>
                    <span className="text-gray-600">/{billingCycle === 'annual' ? 'ano' : 'mês'}</span>
                  </div>
                  {billingCycle === 'annual' && (
                    <p className="text-green-600 text-sm font-medium">
                      Economize {getSavings(plan)}% no plano anual
                    </p>
                  )}
                </div>

                <div className="space-y-3 mb-6">
                  {plan.features.slice(0, 4).map((feature, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </div>
                  ))}
                  {plan.features.length > 4 && (
                    <p className="text-gray-500 text-sm">+{plan.features.length - 4} funcionalidades</p>
                  )}
                </div>

                <button className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-200 ${
                  plan.recommended
                    ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg hover:shadow-xl'
                    : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                }`}>
                  Escolher Plano
                </button>
              </div>
            ))}
          </div>
        ) : (
          // Checkout Form
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Plan Summary */}
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Resumo do Plano</h3>
                
                <div className="flex items-center space-x-4 mb-6">
                  <div className="text-blue-600">{selectedPlan.icon}</div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900">{selectedPlan.name}</h4>
                    <p className="text-gray-600">{selectedPlan.description}</p>
                  </div>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Plano {selectedPlan.name}</span>
                    <span className="font-semibold">
                      R$ {getPrice(selectedPlan).toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Cobrança</span>
                    <span className="text-gray-600 capitalize">{billingCycle === 'annual' ? 'Anual' : 'Mensal'}</span>
                  </div>
                  {billingCycle === 'annual' && (
                    <div className="flex justify-between items-center text-green-600">
                      <span>Desconto anual</span>
                      <span>-{getSavings(selectedPlan)}%</span>
                    </div>
                  )}
                  <hr className="border-gray-200" />
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>Total</span>
                    <span>R$ {getPrice(selectedPlan).toFixed(2).replace('.', ',')}</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <h5 className="font-semibold text-gray-900">Incluído no plano:</h5>
                  {selectedPlan.features.map((feature, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setSelectedPlan(null)}
                  className="w-full mt-6 py-2 px-4 text-blue-600 hover:text-blue-700 transition-colors"
                >
                  Alterar plano
                </button>
              </div>

              {/* Payment Form */}
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Informações de Pagamento</h3>
                
                {/* Payment Method Selection */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Método de Pagamento
                  </label>
                  <div className="space-y-3">
                    <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="credit_card"
                        checked={paymentMethod === 'credit_card'}
                        onChange={(e) => setPaymentMethod(e.target.value as any)}
                        className="text-blue-600"
                      />
                      <CreditCard className="w-5 h-5 text-gray-600" />
                      <span className="text-gray-700">Cartão de Crédito</span>
                    </label>
                    <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="pix"
                        checked={paymentMethod === 'pix'}
                        onChange={(e) => setPaymentMethod(e.target.value as any)}
                        className="text-blue-600"
                      />
                      <div className="w-5 h-5 bg-green-500 rounded"></div>
                      <span className="text-gray-700">PIX</span>
                    </label>
                    <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="boleto"
                        checked={paymentMethod === 'boleto'}
                        onChange={(e) => setPaymentMethod(e.target.value as any)}
                        className="text-blue-600"
                      />
                      <div className="w-5 h-5 bg-yellow-500 rounded"></div>
                      <span className="text-gray-700">Boleto Bancário</span>
                    </label>
                    <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="stripe"
                        checked={paymentMethod === 'stripe'}
                        onChange={(e) => setPaymentMethod(e.target.value as any)}
                        className="text-blue-600"
                      />
                      <div className="w-5 h-5 bg-purple-500 rounded flex items-center justify-center">
                        <span className="text-white text-xs font-bold">S</span>
                      </div>
                      <span className="text-gray-700">Stripe (Cartão Internacional)</span>
                    </label>
                  </div>
                </div>

                {/* Billing Info */}
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nome Completo
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={user?.google_user_data.name || ''}
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={user?.email || ''}
                      readOnly
                    />
                  </div>
                </div>

                {/* Security Notice */}
                <div className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg mb-6">
                  <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800">
                    <p className="font-medium">Pagamento Seguro</p>
                    <p>Suas informações estão protegidas com criptografia SSL.</p>
                  </div>
                </div>

                {/* Stripe Payment Form or Checkout Button */}
                {stripeClientSecret && stripePublishableKey && paymentMethod === 'stripe' ? (
                  <StripePaymentForm
                    clientSecret={stripeClientSecret}
                    publishableKey={stripePublishableKey}
                    amount={getPrice(selectedPlan)}
                    planName={selectedPlan.name}
                    onSuccess={() => {
                      navigate(`/checkout/success?subscription=${Date.now()}`);
                    }}
                    onError={(error) => {
                      console.error('Stripe payment error:', error);
                      alert(`Erro no pagamento: ${error}`);
                      setStripeClientSecret(null);
                      setStripePublishableKey(null);
                    }}
                  />
                ) : (
                  <button
                    onClick={handleCheckout}
                    disabled={isProcessing}
                    className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isProcessing ? (
                      <div className="flex items-center justify-center space-x-2">
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Processando...</span>
                      </div>
                    ) : (
                      `Finalizar Pagamento - R$ ${getPrice(selectedPlan).toFixed(2).replace('.', ',')}`
                    )}
                  </button>
                )}

                <p className="text-xs text-gray-500 text-center mt-4">
                  Ao finalizar o pagamento você concorda com nossos{' '}
                  <a href="#" className="text-blue-600 hover:underline">Termos de Uso</a>
                  {' '}e{' '}
                  <a href="#" className="text-blue-600 hover:underline">Política de Privacidade</a>
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Trust Indicators */}
        <div className="text-center mt-12">
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-8 text-gray-600">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-green-600" />
              <span className="text-sm">Pagamento 100% seguro</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="w-5 h-5 text-green-600" />
              <span className="text-sm">14 dias de teste grátis</span>
            </div>
            <div className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-500" />
              <span className="text-sm">Garantia de 30 dias</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
