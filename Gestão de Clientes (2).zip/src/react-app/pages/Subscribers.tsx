import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import Layout from '@/react-app/components/Layout';
import { 
  Users, 
  Search, 
  UserCheck, 
  UserX, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Crown
} from 'lucide-react';

interface Subscriber {
  id: string;
  email: string;
  name: string;
  picture?: string;
  subscription_id?: number;
  plan_id?: string;
  plan_name?: string;
  status: string;
  billing_cycle?: string;
  amount?: number;
  start_date?: string;
  end_date?: string;
  next_billing_date?: string;
  days_until_expiry?: number;
  is_expired: boolean;
  is_expiring_soon: boolean;
  created_at: string;
}

export default function Subscribers() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'expired' | 'expiring'>('all');
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    expired: 0,
    expiring: 0,
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      loadSubscribers();
    }
  }, [user]);

  const loadSubscribers = async () => {
    try {
      const response = await fetch('/api/admin/subscribers');
      if (response.ok) {
        const data = await response.json();
        setSubscribers(data);
        
        // Calculate stats
        const total = data.length;
        const active = data.filter((s: Subscriber) => s.status === 'active').length;
        const expired = data.filter((s: Subscriber) => s.is_expired).length;
        const expiring = data.filter((s: Subscriber) => s.is_expiring_soon).length;
        
        setStats({ total, active, expired, expiring });
      }
    } catch (error) {
      console.error('Erro ao carregar assinantes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBlockUser = async (userId: string) => {
    if (!confirm('Tem certeza que deseja bloquear este usuário?')) return;

    try {
      const response = await fetch(`/api/admin/subscribers/${userId}/block`, {
        method: 'POST',
      });

      if (response.ok) {
        loadSubscribers(); // Reload data
      }
    } catch (error) {
      console.error('Erro ao bloquear usuário:', error);
    }
  };

  const handleUnblockUser = async (userId: string) => {
    try {
      const response = await fetch(`/api/admin/subscribers/${userId}/unblock`, {
        method: 'POST',
      });

      if (response.ok) {
        loadSubscribers(); // Reload data
      }
    } catch (error) {
      console.error('Erro ao desbloquear usuário:', error);
    }
  };

  const handleCheckExpiredSubscriptions = async () => {
    try {
      const response = await fetch('/api/admin/check-expired-subscriptions', {
        method: 'POST',
      });

      if (response.ok) {
        loadSubscribers(); // Reload data
        alert('Verificação de assinaturas expiradas concluída!');
      }
    } catch (error) {
      console.error('Erro ao verificar assinaturas expiradas:', error);
    }
  };

  const filteredSubscribers = subscribers.filter(subscriber => {
    const matchesSearch = subscriber.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subscriber.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = statusFilter === 'all' || 
      (statusFilter === 'active' && subscriber.status === 'active') ||
      (statusFilter === 'expired' && subscriber.is_expired) ||
      (statusFilter === 'expiring' && subscriber.is_expiring_soon);

    return matchesSearch && matchesFilter;
  });

  if (isPending || loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Gerenciar Assinantes</h1>
            <p className="text-gray-600">Controle de assinaturas e usuários do sistema</p>
          </div>
          <button
            onClick={handleCheckExpiredSubscriptions}
            className="flex items-center gap-2 bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors"
          >
            <RefreshCw className="w-5 h-5" />
            Verificar Expiradas
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</p>
              </div>
              <div className="p-3 rounded-lg bg-blue-500 text-white">
                <Users className="w-6 h-6" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ativos</p>
                <p className="text-2xl font-bold text-green-600 mt-1">{stats.active}</p>
              </div>
              <div className="p-3 rounded-lg bg-green-500 text-white">
                <CheckCircle className="w-6 h-6" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Expirando</p>
                <p className="text-2xl font-bold text-orange-600 mt-1">{stats.expiring}</p>
              </div>
              <div className="p-3 rounded-lg bg-orange-500 text-white">
                <AlertTriangle className="w-6 h-6" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Expirados</p>
                <p className="text-2xl font-bold text-red-600 mt-1">{stats.expired}</p>
              </div>
              <div className="p-3 rounded-lg bg-red-500 text-white">
                <XCircle className="w-6 h-6" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar por email ou nome..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            <option value="all">Todos</option>
            <option value="active">Ativos</option>
            <option value="expiring">Expirando</option>
            <option value="expired">Expirados</option>
          </select>
        </div>

        {/* Subscribers Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Usuário
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Plano
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Vencimento
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Valor
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredSubscribers.map((subscriber) => (
                  <tr key={subscriber.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          {subscriber.picture ? (
                            <img 
                              className="h-10 w-10 rounded-full" 
                              src={subscriber.picture} 
                              alt="" 
                            />
                          ) : (
                            <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                              <Users className="h-5 w-5 text-gray-500" />
                            </div>
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {subscriber.name}
                          </div>
                          <div className="text-sm text-gray-500">
                            {subscriber.email}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {subscriber.plan_name ? (
                          <>
                            <Crown className="w-4 h-4 text-yellow-500 mr-2" />
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                {subscriber.plan_name}
                              </div>
                              <div className="text-sm text-gray-500">
                                {subscriber.billing_cycle === 'annual' ? 'Anual' : 'Mensal'}
                              </div>
                            </div>
                          </>
                        ) : (
                          <span className="text-sm text-gray-500">Sem plano</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col gap-1">
                        <span className={`px-2 py-1 text-xs rounded-full w-fit ${
                          subscriber.status === 'active' && !subscriber.is_expired
                            ? 'bg-green-100 text-green-700'
                            : subscriber.is_expired
                            ? 'bg-red-100 text-red-700'
                            : subscriber.is_expiring_soon
                            ? 'bg-orange-100 text-orange-700'
                            : 'bg-gray-100 text-gray-700'
                        }`}>
                          {subscriber.is_expired ? 'Expirado' :
                           subscriber.is_expiring_soon ? 'Expirando' :
                           subscriber.status === 'active' ? 'Ativo' : 'Inativo'}
                        </span>
                        {subscriber.is_expiring_soon && subscriber.days_until_expiry !== undefined && (
                          <span className="text-xs text-orange-600">
                            {subscriber.days_until_expiry} dias restantes
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {subscriber.next_billing_date ? 
                        new Date(subscriber.next_billing_date).toLocaleDateString('pt-BR') : 
                        subscriber.end_date ?
                        new Date(subscriber.end_date).toLocaleDateString('pt-BR') :
                        '-'
                      }
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {subscriber.amount ? 
                        `R$ ${subscriber.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : 
                        '-'
                      }
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end gap-2">
                        {subscriber.status === 'active' ? (
                          <button
                            onClick={() => handleBlockUser(subscriber.id)}
                            className="text-red-600 hover:text-red-900 hover:bg-red-50 p-2 rounded-lg transition-colors"
                            title="Bloquear usuário"
                          >
                            <UserX className="w-4 h-4" />
                          </button>
                        ) : (
                          <button
                            onClick={() => handleUnblockUser(subscriber.id)}
                            className="text-green-600 hover:text-green-900 hover:bg-green-50 p-2 rounded-lg transition-colors"
                            title="Desbloquear usuário"
                          >
                            <UserCheck className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredSubscribers.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">
                {searchTerm || statusFilter !== 'all' 
                  ? 'Nenhum assinante encontrado' 
                  : 'Nenhum assinante cadastrado'}
              </p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
