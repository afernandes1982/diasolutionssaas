import { useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import LoginButton from '@/react-app/components/LoginButton';
import FeaturesShowcase from '@/react-app/components/FeaturesShowcase';
import DemoSection from '@/react-app/components/DemoSection';
import PricingSection from '@/react-app/components/PricingSection';
import { 
  Loader2, 
  ArrowRight, 
  Star, 
  Zap, 
  Shield, 
  TrendingUp,
  CheckCircle,
  Play,
  Award
} from 'lucide-react';

export default function Home() {
  const { user, isPending, redirectToLogin } = useAuth();
  const navigate = useNavigate();

  const handleGetStarted = (planId?: string) => {
    if (user) {
      if (planId) {
        navigate(`/checkout?plan=${planId}&cycle=monthly`);
      } else {
        navigate('/checkout');
      }
    } else {
      redirectToLogin();
    }
  };

  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  if (isPending) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <div className="animate-spin">
          <Loader2 className="w-10 h-10 text-blue-600" />
        </div>
      </div>
    );
  }

  if (user) {
    return null; // Will redirect to dashboard
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 px-6 py-4 bg-white/95 backdrop-blur-lg border-b border-blue-100">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img 
              src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
              alt="DIA Solutions AI" 
              className="h-16 w-auto"
            />
            <span className="text-gray-800 text-xl font-bold">DIA Solutions AI</span>
          </div>
          <div className="flex items-center space-x-6">
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#features" className="text-gray-700 hover:text-blue-600 transition-colors">Funcionalidades</a>
              <a href="#demo" className="text-gray-700 hover:text-blue-600 transition-colors">Demo</a>
              <a href="#pricing" className="text-gray-700 hover:text-blue-600 transition-colors">Preços</a>
              <a href="/checkout/test" className="text-gray-700 hover:text-blue-600 transition-colors">Teste Checkout</a>
            </nav>
            <LoginButton onClick={redirectToLogin} />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-20 px-6 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Background decorations */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl animate-blob"></div>
          <div className="absolute top-20 right-10 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
          <div className="absolute bottom-20 left-20 w-72 h-72 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div>
        </div>

        <div className="max-w-7xl mx-auto relative">
          <div className="text-center mb-16">
            {/* Badge */}
            <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-8">
              <Award className="w-4 h-4" />
              <span>A Nova Geração de Gestão para Agências de IA</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-8 leading-tight">
              Transforme Sua Agência de IA em uma{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Máquina de Crescimento
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-xl md:text-2xl text-gray-700 mb-12 max-w-4xl mx-auto leading-relaxed">
              Pare de perder tempo com planilhas desorganizadas. Nossa plataforma automatiza sua gestão, 
              padroniza processos e multiplica seus resultados em <strong>30 dias</strong>.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <button
                onClick={() => handleGetStarted()}
                className="inline-flex items-center space-x-3 bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl text-lg"
              >
                <span>Começar Teste Grátis</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="inline-flex items-center space-x-3 bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all duration-300 shadow-lg border border-gray-200">
                <Play className="w-5 h-5" />
                <span>Ver Demo (2 min)</span>
              </button>
            </div>

            {/* Social Proof */}
            <div className="mt-12 flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-8 text-gray-600">
              <div className="flex items-center space-x-2">
                <div className="flex -space-x-2">
                  {[1,2,3,4,5].map(i => (
                    <div key={i} className="w-8 h-8 bg-blue-500 rounded-full border-2 border-white"></div>
                  ))}
                </div>
                <span className="text-sm font-medium">Sistema testado e aprovado</span>
              </div>
              <div className="flex items-center space-x-1">
                {[1,2,3,4,5].map(i => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
                <span className="text-sm font-medium ml-2">Interface intuitiva e eficiente</span>
              </div>
            </div>
          </div>

          {/* Hero Image/Preview */}
          <div className="relative max-w-5xl mx-auto">
            <div className="bg-white rounded-2xl shadow-2xl p-8 border border-gray-200">
              <div className="grid md:grid-cols-3 gap-6">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Crescimento</div>
                      <div className="text-sm text-gray-600">Este mês</div>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-blue-600">+47%</div>
                  <div className="text-sm text-gray-600">em novos clientes</div>
                </div>

                <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Eficiência</div>
                      <div className="text-sm text-gray-600">Processos</div>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-green-600">95%</div>
                  <div className="text-sm text-gray-600">sem erros</div>
                </div>

                <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                      <Zap className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Economia</div>
                      <div className="text-sm text-gray-600">De tempo</div>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-purple-600">70%</div>
                  <div className="text-sm text-gray-600">menos gestão</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Por Que Escolher a DIA Solutions?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Uma plataforma desenvolvida para maximizar o potencial de crescimento da sua agência de IA.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <TrendingUp className="w-8 h-8" />,
                title: 'Aumente sua Receita em 3x',
                description: 'Processos organizados permitem atender mais clientes sem perder qualidade.',
                result: '+250% faturamento médio'
              },
              {
                icon: <Zap className="w-8 h-8" />,
                title: 'Economize 20h por Semana',
                description: 'Automações inteligentes eliminam tarefas repetitivas e burocráticas.',
                result: '70% menos tempo em gestão'
              },
              {
                icon: <Shield className="w-8 h-8" />,
                title: 'Zero Erros de Processo',
                description: 'Checklists padronizados garantem que nada seja esquecido.',
                result: '95% processos sem falhas'
              },
              {
                icon: <CheckCircle className="w-8 h-8" />,
                title: 'Satisfação do Cliente',
                description: 'Clientes mais felizes com transparência total do progresso.',
                result: '4.9/5 NPS médio'
              },
              {
                icon: <Star className="w-8 h-8" />,
                title: 'Escale Sem Limites',
                description: 'Cresça de 10 para 100+ clientes mantendo a mesma qualidade.',
                result: 'Crescimento ilimitado'
              },
              {
                icon: <ArrowRight className="w-8 h-8" />,
                title: 'ROI Garantido',
                description: 'Retorno do investimento comprovado em menos de 30 dias.',
                result: 'ROI em 30 dias'
              }
            ].map((benefit, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300 border border-gray-100">
                <div className="text-blue-600 mb-4">{benefit.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600 mb-4">{benefit.description}</p>
                <div className="text-sm font-semibold text-green-600 bg-green-50 px-3 py-1 rounded-full inline-block">
                  {benefit.result}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Showcase */}
      <div id="features">
        <FeaturesShowcase />
      </div>

      {/* Demo Section */}
      <div id="demo">
        <DemoSection />
      </div>

      {/* Pricing Section */}
      <div id="pricing">
        <PricingSection onGetStarted={handleGetStarted} />
      </div>

      {/* Final CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-br from-blue-600 to-purple-700 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Pronto para Transformar Sua Agência?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Descubra como nossa plataforma pode revolucionar a gestão da sua agência de IA.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <button
              onClick={() => handleGetStarted()}
              className="inline-flex items-center space-x-3 bg-white text-blue-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-all duration-300 shadow-lg text-lg"
            >
              <span>Começar Teste Grátis de 14 Dias</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
          <p className="text-sm mt-6 opacity-75">
            Sem cartão de crédito • Cancele quando quiser • Suporte 24/7
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 text-gray-800" style={{ backgroundColor: '#E6E6FA' }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center space-x-4 mb-4">
                <img 
                  src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
                  alt="DIA Solutions AI" 
                  className="h-36 w-auto"
                />
                <span className="text-gray-800 text-lg font-bold">DIA Solutions AI</span>
              </div>
              
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Produto</h4>
              <ul className="space-y-2 text-gray-600">
                <li><a href="#features" className="hover:text-blue-600 transition-colors">Funcionalidades</a></li>
                <li><a href="#demo" className="hover:text-blue-600 transition-colors">Demo</a></li>
                <li><a href="#pricing" className="hover:text-blue-600 transition-colors">Preços</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-blue-600 transition-colors">Documentação</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">Tutoriais</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">Contato</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-400 mt-8 pt-8 text-center text-gray-600">
            <p>&copy; 2025 DIA Solutions AI. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
