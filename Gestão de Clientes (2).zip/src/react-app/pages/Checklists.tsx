import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import Layout from '@/react-app/components/Layout';
import ClientChecklistForm from '@/react-app/components/ClientChecklistForm';
import AddChecklistItemForm from '@/react-app/components/AddChecklistItemForm';
import { Plus, Search, Trash2, CheckCircle, User, List, ChevronDown, ChevronRight } from 'lucide-react';
import type { ClientChecklistType, ClientChecklistItemType, ClientType, ChecklistTemplateType } from '@/shared/types';

interface ClientChecklistWithDetails extends ClientChecklistType {
  client_name?: string;
  client_company?: string;
  template_name?: string;
  items?: ClientChecklistItemType[];
  items_count?: number;
  completed_count?: number;
}

export default function Checklists() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [checklists, setChecklists] = useState<ClientChecklistWithDetails[]>([]);
  const [clients, setClients] = useState<ClientType[]>([]);
  const [templates, setTemplates] = useState<ChecklistTemplateType[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [expandedChecklists, setExpandedChecklists] = useState<Set<number>>(new Set());
  const [showAddItemForm, setShowAddItemForm] = useState<number | null>(null);

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      const [checklistsRes, clientsRes, templatesRes] = await Promise.all([
        fetch('/api/client-checklists'),
        fetch('/api/clients'),
        fetch('/api/checklist-templates'),
      ]);
      
      const checklistsData = await checklistsRes.json();
      const clientsData = await clientsRes.json();
      const templatesData = await templatesRes.json();
      
      setChecklists(checklistsData);
      setClients(clientsData);
      setTemplates(templatesData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadChecklistItems = async (checklistId: number) => {
    try {
      const response = await fetch(`/api/client-checklists/${checklistId}/items`);
      const items = await response.json();
      
      setChecklists(checklists.map(c => 
        c.id === checklistId ? { ...c, items } : c
      ));
    } catch (error) {
      console.error('Erro ao carregar itens do checklist:', error);
    }
  };

  const handleCreateChecklist = async (data: { client_id: number; checklist_template_id: number; name?: string }) => {
    try {
      const response = await fetch('/api/client-checklists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        const newChecklist = await response.json();
        const client = clients.find(c => c.id === newChecklist.client_id);
        const template = templates.find(t => t.id === newChecklist.checklist_template_id);
        
        const checklistWithDetails = {
          ...newChecklist,
          client_name: client?.name,
          client_company: client?.company,
          template_name: template?.name,
          items_count: 0,
          completed_count: 0,
        };
        
        setChecklists([checklistWithDetails, ...checklists]);
        setShowForm(false);
      }
    } catch (error) {
      console.error('Erro ao criar checklist:', error);
    }
  };

  const handleDeleteChecklist = async (checklistId: number) => {
    if (!confirm('Tem certeza que deseja excluir este checklist?')) return;

    try {
      const response = await fetch(`/api/client-checklists/${checklistId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setChecklists(checklists.filter(c => c.id !== checklistId));
      }
    } catch (error) {
      console.error('Erro ao excluir checklist:', error);
    }
  };

  const handleToggleItem = async (checklistId: number, itemId: number, isCompleted: boolean) => {
    try {
      const response = await fetch(`/api/client-checklist-items/${itemId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_completed: isCompleted }),
      });

      if (response.ok) {
        await loadChecklistItems(checklistId);
        // Reload main list to update completion stats
        await loadData();
      }
    } catch (error) {
      console.error('Erro ao atualizar item:', error);
    }
  };

  const handleUpdateItemNotes = async (checklistId: number, itemId: number, notes: string) => {
    try {
      const response = await fetch(`/api/client-checklist-items/${itemId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes }),
      });

      if (response.ok) {
        await loadChecklistItems(checklistId);
      }
    } catch (error) {
      console.error('Erro ao atualizar notas:', error);
    }
  };

  const handleAddItem = async (checklistId: number, data: { title: string; description?: string }) => {
    try {
      const response = await fetch(`/api/client-checklists/${checklistId}/items`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        await loadChecklistItems(checklistId);
        await loadData(); // Reload to update counts
        setShowAddItemForm(null);
      }
    } catch (error) {
      console.error('Erro ao adicionar item:', error);
    }
  };

  const toggleChecklistExpanded = async (checklistId: number) => {
    const newExpanded = new Set(expandedChecklists);
    
    if (expandedChecklists.has(checklistId)) {
      newExpanded.delete(checklistId);
    } else {
      newExpanded.add(checklistId);
      // Load items if not loaded yet
      const checklist = checklists.find(c => c.id === checklistId);
      if (checklist && !checklist.items) {
        await loadChecklistItems(checklistId);
      }
    }
    
    setExpandedChecklists(newExpanded);
  };

  const filteredChecklists = checklists.filter(checklist =>
    checklist.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    checklist.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    checklist.client_company?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isPending || loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Checklists de Clientes</h1>
            <p className="text-gray-600">Acompanhe o progresso de implementação dos seus clientes</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Novo Checklist
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Buscar checklists..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
        </div>

        {/* Checklists List */}
        <div className="space-y-4">
          {filteredChecklists.map((checklist) => {
            const progressPercentage = checklist.items_count && checklist.items_count > 0 
              ? Math.round((checklist.completed_count || 0) / checklist.items_count * 100) 
              : 0;

            return (
              <div key={checklist.id} className="bg-white rounded-xl shadow-sm border border-gray-200">
                {/* Checklist Header */}
                <div className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <button
                          onClick={() => toggleChecklistExpanded(checklist.id)}
                          className="p-1 hover:bg-gray-100 rounded transition-colors"
                        >
                          {expandedChecklists.has(checklist.id) ? (
                            <ChevronDown className="w-5 h-5 text-gray-600" />
                          ) : (
                            <ChevronRight className="w-5 h-5 text-gray-600" />
                          )}
                        </button>
                        <h3 className="text-lg font-semibold text-gray-900">{checklist.name}</h3>
                        {checklist.is_completed && (
                          <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">
                            Concluído
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-600 ml-9 mb-3">
                        <span className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          {checklist.client_name}
                          {checklist.client_company && ` (${checklist.client_company})`}
                        </span>
                        <span className="flex items-center gap-1">
                          <List className="w-4 h-4" />
                          {checklist.template_name}
                        </span>
                      </div>

                      {/* Progress Bar */}
                      <div className="ml-9">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-sm text-gray-600">
                            Progresso: {checklist.completed_count || 0} de {checklist.items_count || 0} itens
                          </span>
                          <span className="text-sm font-medium text-purple-600">
                            {progressPercentage}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${progressPercentage}%` }}
                          ></div>
                        </div>
                      </div>

                      <div className="text-sm text-gray-500 ml-9 mt-2">
                        Criado em {new Date(checklist.created_at).toLocaleDateString('pt-BR')}
                        {checklist.completed_at && (
                          <span> • Concluído em {new Date(checklist.completed_at).toLocaleDateString('pt-BR')}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleDeleteChecklist(checklist.id)}
                        className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Excluir checklist"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Checklist Items */}
                {expandedChecklists.has(checklist.id) && (
                  <div className="border-t border-gray-200 px-6 py-4">
                    {/* Add Item Button */}
                    <div className="mb-4">
                      <button
                        onClick={() => setShowAddItemForm(checklist.id)}
                        className="flex items-center gap-2 px-3 py-2 text-sm bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                        Adicionar Item
                      </button>
                    </div>

                    {checklist.items && checklist.items.length > 0 ? (
                      <div className="space-y-3">
                        {checklist.items.map((item) => (
                          <div key={item.id} className="p-4 bg-gray-50 rounded-lg">
                            <div className="flex items-start gap-3">
                              <button
                                onClick={() => handleToggleItem(checklist.id, item.id, !item.is_completed)}
                                className={`flex-shrink-0 w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                                  item.is_completed
                                    ? 'bg-green-500 border-green-500 text-white'
                                    : 'border-gray-300 hover:border-green-400'
                                }`}
                              >
                                {item.is_completed && <CheckCircle className="w-3 h-3" />}
                              </button>
                              
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className={`text-sm font-medium ${
                                    item.is_completed ? 'text-gray-500 line-through' : 'text-gray-900'
                                  }`}>
                                    {item.title}
                                  </span>
                                  {item.is_completed && (
                                    <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">
                                      Concluído
                                    </span>
                                  )}
                                </div>
                                
                                {item.description && (
                                  <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                                )}
                                
                                {item.completed_at && (
                                  <p className="text-xs text-gray-500 mb-2">
                                    Concluído em {new Date(item.completed_at).toLocaleDateString('pt-BR')} às {new Date(item.completed_at).toLocaleTimeString('pt-BR')}
                                  </p>
                                )}

                                {/* Notes */}
                                <textarea
                                  value={item.notes || ''}
                                  onChange={(e) => handleUpdateItemNotes(checklist.id, item.id, e.target.value)}
                                  placeholder="Adicionar observações..."
                                  className="w-full text-sm border border-gray-200 rounded px-2 py-1 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                  rows={2}
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-500">Carregando itens do checklist...</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {filteredChecklists.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">
              {searchTerm ? 'Nenhum checklist encontrado' : 'Nenhum checklist criado ainda'}
            </p>
          </div>
        )}
      </div>

      {/* Checklist Form Modal */}
      {showForm && (
        <ClientChecklistForm
          clients={clients}
          templates={templates}
          onSubmit={handleCreateChecklist}
          onCancel={() => setShowForm(false)}
        />
      )}

      {/* Add Item Form Modal */}
      {showAddItemForm && (
        <AddChecklistItemForm
          onSubmit={(data) => handleAddItem(showAddItemForm, data)}
          onCancel={() => setShowAddItemForm(null)}
        />
      )}
    </Layout>
  );
}
