import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import Layout from '@/react-app/components/Layout';
import { 
  Plus, 
  Search, 
  Calendar, 
  Edit, 
  Trash2, 
  FolderOpen, 
  Clock, 
  CheckCircle,
  AlertCircle,
  DollarSign,
  Target,
  Cpu,
  Bot,
  MessageSquare,
  BarChart,
  Zap
} from 'lucide-react';

interface Project {
  id: number;
  name: string;
  description: string;
  client_id?: number;
  client_name?: string;
  project_type: string;
  status: string;
  start_date: string;
  estimated_end_date: string;
  actual_end_date?: string;
  budget?: number;
  progress_percentage: number;
  technologies: string[];
  team_members: string[];
  created_at: string;
}

interface Client {
  id: number;
  name: string;
  company?: string;
}

interface Developer {
  id: number;
  name: string;
  email: string;
  specialization?: string;
  level: string;
  is_active: boolean;
}

export default function Projects() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [developers, setDevelopers] = useState<Developer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    client_id: '',
    project_type: '',
    status: 'planejamento',
    start_date: '',
    estimated_end_date: '',
    budget: '',
    progress_percentage: '0',
    technologies: [] as string[],
    developer_ids: [] as number[],
    notes: ''
  });
  const [developerSearch, setDeveloperSearch] = useState('');
  const [developerSearch, setDeveloperSearch] = useState('');

  const fetchProjects = async () => {
    try {
      const response = await fetch('/api/projects', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        setProjects(data);
      }
    } catch (error) {
      console.error('Erro ao buscar projetos:', error);
    }
  };

  const fetchClients = async () => {
    try {
      const response = await fetch('/api/clients', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        setClients(data);
      }
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
    }
  };

  const fetchDevelopers = async () => {
    try {
      const response = await fetch('/api/developers', {
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        setDevelopers(data.filter((dev: Developer) => dev.is_active));
      }
    } catch (error) {
      console.error('Erro ao buscar desenvolvedores:', error);
    }
  };

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      Promise.all([fetchProjects(), fetchClients(), fetchDevelopers()])
        .finally(() => setLoading(false));
    }
  }, [user]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'concluido': return 'bg-green-100 text-green-800 border-green-200';
      case 'em_andamento': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'planejamento': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'pausado': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'concluido': return 'Concluído';
      case 'em_andamento': return 'Em Andamento';
      case 'planejamento': return 'Planejamento';
      case 'pausado': return 'Pausado';
      default: return status;
    }
  };

  const getProjectTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'chatbot': return <MessageSquare className="w-5 h-5" />;
      case 'machine learning': return <BarChart className="w-5 h-5" />;
      case 'nlp': return <Cpu className="w-5 h-5" />;
      case 'automação': return <Zap className="w-5 h-5" />;
      case 'assistente virtual': return <Bot className="w-5 h-5" />;
      default: return <FolderOpen className="w-5 h-5" />;
    }
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 50) return 'bg-blue-500';
    if (progress >= 25) return 'bg-yellow-500';
    return 'bg-gray-300';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    
    try {
      const payload = {
        name: formData.name,
        description: formData.description || null,
        client_id: formData.client_id ? parseInt(formData.client_id) : null,
        project_type: formData.project_type || null,
        status: formData.status,
        start_date: formData.start_date || null,
        estimated_end_date: formData.estimated_end_date || null,
        budget: formData.budget ? parseFloat(formData.budget) : null,
        progress_percentage: parseInt(formData.progress_percentage),
        technologies: formData.technologies,
        developer_ids: formData.developer_ids,
        notes: formData.notes || null
      };

      const url = editingProject ? `/api/projects/${editingProject.id}` : '/api/projects';
      const method = editingProject ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        await fetchProjects();
        setShowForm(false);
        setEditingProject(null);
        resetForm();
      } else {
        const errorData = await response.json();
        console.error('Erro ao salvar projeto:', errorData);
        alert('Erro ao salvar projeto: ' + (errorData.error || 'Erro desconhecido'));
      }
    } catch (error) {
      console.error('Erro ao salvar projeto:', error);
      alert('Erro ao salvar projeto: ' + error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (project: Project) => {
    setEditingProject(project);
    setFormData({
      name: project.name,
      description: project.description || '',
      client_id: project.client_id?.toString() || '',
      project_type: project.project_type || '',
      status: project.status,
      start_date: project.start_date || '',
      estimated_end_date: project.estimated_end_date || '',
      budget: project.budget?.toString() || '',
      progress_percentage: project.progress_percentage.toString(),
      technologies: project.technologies || [],
      developer_ids: [], // Will need to fetch from project_developers table
      notes: ''
    });
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir este projeto?')) {
      return;
    }

    try {
      const response = await fetch(`/api/projects/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });

      if (response.ok) {
        setProjects(projects.filter(project => project.id !== id));
      } else {
        const errorData = await response.json();
        alert('Erro ao excluir projeto: ' + (errorData.error || 'Erro desconhecido'));
      }
    } catch (error) {
      console.error('Erro ao excluir projeto:', error);
      alert('Erro ao excluir projeto: ' + error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      client_id: '',
      project_type: '',
      status: 'planejamento',
      start_date: '',
      estimated_end_date: '',
      budget: '',
      progress_percentage: '0',
      technologies: [],
      developer_ids: [],
      notes: ''
    });
    setDeveloperSearch('');
  };

  const addTechnology = (tech: string) => {
    if (tech.trim() && !formData.technologies.includes(tech.trim())) {
      setFormData({
        ...formData,
        technologies: [...formData.technologies, tech.trim()]
      });
    }
  };

  const removeTechnology = (tech: string) => {
    setFormData({
      ...formData,
      technologies: formData.technologies.filter(t => t !== tech)
    });
  };

  const filteredProjects = projects.filter(project =>
    project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.project_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (project.client_name && project.client_name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === 'em_andamento').length;
  const completedProjects = projects.filter(p => p.status === 'concluido').length;
  const totalBudget = projects.reduce((sum, p) => sum + (p.budget || 0), 0);

  if (isPending || loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Projetos</h1>
            <p className="text-gray-600">Gerencie todos os projetos de IA da sua agência</p>
          </div>
          <button
            onClick={() => {
              setShowForm(true);
              setEditingProject(null);
              resetForm();
            }}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Novo Projeto
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-700">Total de Projetos</p>
                <p className="text-2xl font-bold text-blue-900">{totalProjects}</p>
              </div>
              <FolderOpen className="w-8 h-8 text-blue-600" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-700">Em Andamento</p>
                <p className="text-2xl font-bold text-green-900">{activeProjects}</p>
              </div>
              <Clock className="w-8 h-8 text-green-600" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-700">Concluídos</p>
                <p className="text-2xl font-bold text-purple-900">{completedProjects}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-purple-600" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl border border-orange-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-700">Valor Total</p>
                <p className="text-2xl font-bold text-orange-900">
                  R$ {totalBudget.toLocaleString('pt-BR')}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-orange-600" />
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Buscar projetos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Project Form Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">
                  {editingProject ? 'Editar Projeto' : 'Novo Projeto'}
                </h2>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Nome do Projeto *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Cliente
                      </label>
                      <select
                        value={formData.client_id}
                        onChange={(e) => setFormData({ ...formData, client_id: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      >
                        <option value="">Selecione um cliente</option>
                        {clients.map((client) => (
                          <option key={client.id} value={client.id}>
                            {client.name} {client.company && `- ${client.company}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Descrição
                    </label>
                    <textarea
                      rows={3}
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      disabled={submitting}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Tipo de Projeto
                      </label>
                      <select
                        value={formData.project_type}
                        onChange={(e) => setFormData({ ...formData, project_type: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      >
                        <option value="">Selecione o tipo</option>
                        <option value="Chatbot">Chatbot</option>
                        <option value="Machine Learning">Machine Learning</option>
                        <option value="NLP">NLP</option>
                        <option value="Automação">Automação</option>
                        <option value="Assistente Virtual">Assistente Virtual</option>
                        <option value="API">API</option>
                        <option value="Web App">Web App</option>
                        <option value="Mobile App">Mobile App</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Status
                      </label>
                      <select
                        value={formData.status}
                        onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      >
                        <option value="planejamento">Planejamento</option>
                        <option value="em_andamento">Em Andamento</option>
                        <option value="pausado">Pausado</option>
                        <option value="concluido">Concluído</option>
                        <option value="cancelado">Cancelado</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Progresso (%)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={formData.progress_percentage}
                        onChange={(e) => setFormData({ ...formData, progress_percentage: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Data de Início
                      </label>
                      <input
                        type="date"
                        value={formData.start_date}
                        onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Prazo Estimado
                      </label>
                      <input
                        type="date"
                        value={formData.estimated_end_date}
                        onChange={(e) => setFormData({ ...formData, estimated_end_date: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Orçamento (R$)
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={formData.budget}
                        onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Tecnologias
                    </label>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {formData.technologies.map((tech, index) => (
                        <span key={index} className="inline-flex items-center gap-1 px-2 py-1 text-sm bg-blue-100 text-blue-800 rounded-md">
                          {tech}
                          <button
                            type="button"
                            onClick={() => removeTechnology(tech)}
                            className="text-blue-600 hover:text-blue-800"
                            disabled={submitting}
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                    <input
                      type="text"
                      placeholder="Digite uma tecnologia e pressione Enter"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          addTechnology(e.currentTarget.value);
                          e.currentTarget.value = '';
                        }
                      }}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      disabled={submitting}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Desenvolvedores Responsáveis
                    </label>
                    
                    {/* Search Input */}
                    <div className="relative mb-2">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="text"
                        placeholder="Buscar desenvolvedor..."
                        value={developerSearch}
                        onChange={(e) => setDeveloperSearch(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        disabled={submitting}
                      />
                    </div>

                    {/* Selected Developers */}
                    {formData.developer_ids.length > 0 && (
                      <div className="mb-2">
                        <div className="flex flex-wrap gap-2">
                          {formData.developer_ids.map((devId) => {
                            const developer = developers.find(d => d.id === devId);
                            if (!developer) return null;
                            return (
                              <span
                                key={devId}
                                className="inline-flex items-center gap-1 px-2 py-1 text-sm bg-blue-100 text-blue-800 rounded-md"
                              >
                                {developer.name}
                                <button
                                  type="button"
                                  onClick={() => {
                                    setFormData({
                                      ...formData,
                                      developer_ids: formData.developer_ids.filter(id => id !== devId)
                                    });
                                  }}
                                  disabled={submitting}
                                  className="text-blue-600 hover:text-blue-800 ml-1"
                                  title="Remover desenvolvedor"
                                >
                                  ×
                                </button>
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Developer Selection List */}
                    <div className="border rounded-lg max-h-40 overflow-y-auto bg-white">
                      {developers
                        .filter(developer => 
                          developer.name.toLowerCase().includes(developerSearch.toLowerCase()) ||
                          (developer.specialization && developer.specialization.toLowerCase().includes(developerSearch.toLowerCase()))
                        )
                        .map((developer) => (
                          <button
                            key={developer.id}
                            type="button"
                            onClick={() => {
                              if (formData.developer_ids.includes(developer.id)) {
                                setFormData({
                                  ...formData,
                                  developer_ids: formData.developer_ids.filter(id => id !== developer.id)
                                });
                              } else {
                                setFormData({
                                  ...formData,
                                  developer_ids: [...formData.developer_ids, developer.id]
                                });
                              }
                            }}
                            disabled={submitting}
                            className={`w-full text-left px-3 py-2 text-sm hover:bg-gray-50 border-b border-gray-100 last:border-b-0 transition-colors ${
                              formData.developer_ids.includes(developer.id) 
                                ? 'bg-blue-50 text-blue-700' 
                                : 'text-gray-700'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className={`w-4 h-4 border-2 rounded flex items-center justify-center ${
                                  formData.developer_ids.includes(developer.id)
                                    ? 'bg-blue-600 border-blue-600'
                                    : 'border-gray-300'
                                }`}>
                                  {formData.developer_ids.includes(developer.id) && (
                                    <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                    </svg>
                                  )}
                                </div>
                                <span className="font-medium">{developer.name}</span>
                                {developer.specialization && (
                                  <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                                    {developer.specialization}
                                  </span>
                                )}
                              </div>
                              <div className="text-xs text-gray-400">
                                {developer.level === 'junior' && 'Júnior'}
                                {developer.level === 'pleno' && 'Pleno'}
                                {developer.level === 'senior' && 'Sênior'}
                                {developer.level === 'tech_lead' && 'Tech Lead'}
                              </div>
                            </div>
                          </button>
                        ))}
                      
                      {developers.filter(developer => 
                        developer.name.toLowerCase().includes(developerSearch.toLowerCase()) ||
                        (developer.specialization && developer.specialization.toLowerCase().includes(developerSearch.toLowerCase()))
                      ).length === 0 && (
                        <div className="p-3 text-sm text-gray-500 text-center">
                          {developerSearch ? 'Nenhum desenvolvedor encontrado' : 'Nenhum desenvolvedor cadastrado'}
                        </div>
                      )}
                    </div>
                    
                    {developers.length === 0 && (
                      <p className="text-sm text-gray-500 mt-2">
                        Nenhum desenvolvedor cadastrado. <br />
                        Cadastre desenvolvedores na seção "Desenvolvedores" para poder selecioná-los aqui.
                      </p>
                    )}
                  </div>

                  <div className="flex justify-end gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowForm(false);
                        setEditingProject(null);
                        resetForm();
                      }}
                      className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                      disabled={submitting}
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      {submitting && <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>}
                      {editingProject ? 'Atualizar' : 'Criar'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* Projects Grid */}
        <div className="grid gap-6">
          {filteredProjects.map((project) => (
            <div key={project.id} className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        {getProjectTypeIcon(project.project_type)}
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{project.name}</h3>
                        <div className="flex items-center gap-3">
                          <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full border ${getStatusColor(project.status)}`}>
                            {getStatusLabel(project.status)}
                          </span>
                          <span className="text-sm text-gray-500">{project.project_type}</span>
                          {project.client_name && (
                            <>
                              <span className="text-gray-300">•</span>
                              <span className="text-sm text-gray-600">{project.client_name}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    
                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-900">Progresso</h4>
                        <span className="text-sm font-medium text-gray-700">{project.progress_percentage}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(project.progress_percentage)}`}
                          style={{ width: `${project.progress_percentage}%` }}
                        />
                      </div>
                    </div>
                    
                    {/* Project Details */}
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <h5 className="text-sm font-medium text-gray-900 mb-2">Tecnologias</h5>
                        <div className="flex flex-wrap gap-1">
                          {project.technologies.map((tech, index) => (
                            <span key={index} className="inline-flex px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded-md">
                              {tech}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h5 className="text-sm font-medium text-gray-900 mb-2">Equipe</h5>
                        <div className="flex flex-wrap gap-1">
                          {project.team_members.map((member, index) => (
                            <span key={index} className="inline-flex px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded-md">
                              {member}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-6 text-sm text-gray-500">
                      {project.start_date && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          Início: {new Date(project.start_date).toLocaleDateString('pt-BR')}
                        </span>
                      )}
                      {project.estimated_end_date && (
                        <span className="flex items-center gap-1">
                          <Target className="w-4 h-4" />
                          Prazo: {new Date(project.estimated_end_date).toLocaleDateString('pt-BR')}
                        </span>
                      )}
                      {project.budget && (
                        <span className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4" />
                          R$ {project.budget.toLocaleString('pt-BR')}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEdit(project)}
                      className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Editar projeto"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(project.id)}
                      className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Excluir projeto"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProjects.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FolderOpen className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm ? 'Nenhum projeto encontrado' : 'Nenhum projeto cadastrado'}
            </h3>
            <p className="text-gray-500">
              {searchTerm 
                ? 'Tente buscar com outros termos'
                : 'Crie seu primeiro projeto para começar a organizar o trabalho da sua agência'
              }
            </p>
          </div>
        )}

        {/* Info Box */}
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Gestão de Projetos de IA</h3>
              <p className="text-sm text-gray-600 mb-3">
                Organize todos os projetos de implementação de IA da sua agência em um só lugar. 
                Acompanhe progresso, recursos utilizados, equipes envolvidas e prazos de entrega.
              </p>
              <div className="text-xs text-gray-500">
                <p>• Controle completo do ciclo de vida dos projetos</p>
                <p>• Acompanhamento de tecnologias e recursos utilizados</p>
                <p>• Gestão de equipes e responsabilidades</p>
                <p>• Monitoramento de orçamento e prazos</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
