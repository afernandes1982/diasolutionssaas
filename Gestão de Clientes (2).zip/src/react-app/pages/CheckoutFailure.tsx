import { useNavigate } from 'react-router';
import { AlertCircle, ArrowLeft, RefreshCw } from 'lucide-react';

export default function CheckoutFailure() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-red-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
              alt="DIA Solutions AI" 
              className="h-10 w-auto"
            />
            <span className="font-bold text-gray-800 text-lg">Pagamento não realizado</span>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-red-100 rounded-full mb-6">
            <AlertCircle className="w-12 h-12 text-red-600" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Pagamento não realizado
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Houve um problema com o processamento do seu pagamento. Não se preocupe, você pode tentar novamente.
          </p>
        </div>

        {/* Error Details */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">O que aconteceu?</h2>
          
          <div className="space-y-4 text-gray-700">
            <p>Seu pagamento não foi processado com sucesso. Isso pode ter acontecido por alguns motivos:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Dados do cartão incorretos ou cartão sem limite</li>
              <li>Problema temporário na comunicação com o gateway de pagamento</li>
              <li>Pagamento cancelado pelo usuário</li>
              <li>Problema técnico temporário</li>
            </ul>
            <p className="text-sm text-gray-600 mt-4">
              <strong>Importante:</strong> Não foi realizada nenhuma cobrança em seu cartão ou conta.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
          <button
            onClick={() => navigate('/checkout')}
            className="inline-flex items-center space-x-3 bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            <RefreshCw className="w-5 h-5" />
            <span>Tentar Novamente</span>
          </button>
          
          <button
            onClick={() => navigate('/dashboard')}
            className="inline-flex items-center space-x-3 bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all duration-300 shadow-lg border border-gray-200"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Voltar ao Dashboard</span>
          </button>
        </div>

        {/* Support */}
        <div className="text-center mt-12">
          <div className="bg-blue-50 rounded-lg p-6 max-w-md mx-auto">
            <h3 className="font-semibold text-blue-900 mb-2">Precisa de ajuda?</h3>
            <p className="text-blue-800 text-sm mb-4">
              Nossa equipe de suporte está pronta para ajudar você com qualquer problema.
            </p>
            <a
              href="mailto:suporte@diasolutions.ai"
              className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium"
            >
              <span>Entrar em contato</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
