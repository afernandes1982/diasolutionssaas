import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { useAuth } from '@getmocha/users-service/react';
import { 
  CheckCircle, 
  ArrowRight, 
  Mail, 
  Calendar,
  CreditCard
} from 'lucide-react';

interface Subscription {
  id: string;
  planName: string;
  amount: number;
  billingCycle: string;
  nextBillingDate: string;
  status: string;
}

export default function CheckoutSuccess() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const subscriptionId = searchParams.get('subscription');
    
    if (!subscriptionId) {
      navigate('/dashboard');
      return;
    }

    // Fetch subscription details
    const fetchSubscription = async () => {
      try {
        const response = await fetch(`/api/subscriptions/${subscriptionId}`);
        if (response.ok) {
          const data = await response.json();
          setSubscription(data);
        }
      } catch (error) {
        console.error('Error fetching subscription:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSubscription();
  }, [searchParams, navigate]);

  if (!user) {
    navigate('/');
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-green-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
              alt="DIA Solutions AI" 
              className="h-10 w-auto"
            />
            <span className="font-bold text-gray-800 text-lg">Pagamento Concluído</span>
          </div>
          <div className="flex items-center space-x-3">
            {user?.google_user_data.picture && (
              <img
                src={user.google_user_data.picture}
                alt={user.google_user_data.name || user.email}
                className="w-8 h-8 rounded-full"
              />
            )}
            <span className="text-sm text-gray-700">
              {user?.google_user_data.name || user?.email}
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-16">
        {/* Success Icon */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-green-100 rounded-full mb-6">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Pagamento Realizado com Sucesso!
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Bem-vindo à DIA Solutions AI! Sua assinatura foi ativada e você já pode começar a transformar sua agência.
          </p>
        </div>

        {/* Subscription Details */}
        {subscription && (
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Detalhes da Assinatura</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div>
                    <p className="text-sm text-gray-600">Plano</p>
                    <p className="font-semibold text-gray-900">{subscription.planName}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <CreditCard className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-600">Valor</p>
                    <p className="font-semibold text-gray-900">
                      R$ {subscription.amount.toFixed(2).replace('.', ',')} / {subscription.billingCycle === 'annual' ? 'ano' : 'mês'}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Calendar className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-600">Próxima cobrança</p>
                    <p className="font-semibold text-gray-900">
                      {new Date(subscription.nextBillingDate).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div>
                    <p className="text-sm text-gray-600">Status</p>
                    <p className="font-semibold text-green-600 capitalize">{subscription.status}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Next Steps */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Próximos Passos</h2>
          
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-semibold text-sm">1</span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Acesse seu Dashboard</h3>
                <p className="text-gray-600">
                  Comece a explorar todas as funcionalidades disponíveis no seu novo plano.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-semibold text-sm">2</span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Configure seus primeiro clientes</h3>
                <p className="text-gray-600">
                  Adicione seus clientes e comece a organizar seus projetos de IA.
                </p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-semibold text-sm">3</span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Crie seus templates de checklist</h3>
                <p className="text-gray-600">
                  Padronize seus processos com checklists personalizados para cada tipo de projeto.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Support Information */}
        <div className="bg-blue-50 rounded-2xl p-8 mb-8">
          <div className="flex items-start space-x-4">
            <Mail className="w-6 h-6 text-blue-600 mt-1" />
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Precisa de Ajuda?
              </h3>
              <p className="text-gray-700 mb-4">
                Nossa equipe está pronta para ajudar você a aproveitar ao máximo a plataforma. 
                Entre em contato conosco sempre que precisar.
              </p>
              <div className="space-y-2">
                <p className="text-sm text-gray-600">
                  📧 <strong>Email:</strong> suporte@diasolutions.ai
                </p>
                <p className="text-sm text-gray-600">
                  💬 <strong>Chat:</strong> Disponível no painel de controle
                </p>
                <p className="text-sm text-gray-600">
                  📚 <strong>Documentação:</strong> Base de conhecimento completa
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
          <button
            onClick={() => navigate('/dashboard')}
            className="inline-flex items-center space-x-3 bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            <span>Ir para o Dashboard</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          
          <button
            onClick={() => navigate('/clients')}
            className="inline-flex items-center space-x-3 bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all duration-300 shadow-lg border border-gray-200"
          >
            <span>Gerenciar Clientes</span>
          </button>
        </div>

        {/* Guarantee */}
        <div className="text-center mt-12 p-6 bg-yellow-50 rounded-xl border border-yellow-200">
          <p className="text-yellow-800 font-medium">
            🛡️ <strong>Garantia de 30 dias</strong> - Não está satisfeito? 
            Oferecemos reembolso total sem perguntas nos primeiros 30 dias.
          </p>
        </div>
      </div>
    </div>
  );
}
