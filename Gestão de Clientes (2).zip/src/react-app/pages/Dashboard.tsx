import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import Layout from '@/react-app/components/Layout';
import { Users, CreditCard, TrendingUp, AlertCircle, RefreshCw } from 'lucide-react';
import type { ClientType, PaymentType } from '@/shared/types';

export default function Dashboard() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalClients: 0,
    activeClients: 0,
    pendingPayments: 0,
    totalRevenue: 0,
  });
  const [recentClients, setRecentClients] = useState<ClientType[]>([]);
  const [upcomingPayments, setUpcomingPayments] = useState<PaymentType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  // Atualizar dados quando a página se torna visível
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden && user) {
        loadDashboardData();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Também atualizar quando a janela ganha foco
    const handleFocus = () => {
      if (user) {
        loadDashboardData();
      }
    };
    
    window.addEventListener('focus', handleFocus);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
    };
  }, [user]);

  // Atualização automática a cada 30 segundos
  useEffect(() => {
    if (!user) return;
    
    const interval = setInterval(() => {
      loadDashboardData();
    }, 30000);

    return () => clearInterval(interval);
  }, [user]);

  const loadDashboardData = async () => {
    try {
      const [clientsRes, paymentsRes] = await Promise.all([
        fetch('/api/clients'),
        fetch('/api/payments'),
      ]);

      const clients: ClientType[] = await clientsRes.json();
      const payments: PaymentType[] = await paymentsRes.json();

      // Calculate stats
      const totalClients = clients.length;
      const activeClients = clients.filter(c => c.status === 'ativo').length;
      const pendingPayments = payments.filter(p => !p.is_paid).length;
      const totalRevenue = payments
        .filter(p => p.is_paid)
        .reduce((sum, p) => sum + p.amount, 0);

      setStats({
        totalClients,
        activeClients,
        pendingPayments,
        totalRevenue,
      });

      // Recent clients (last 5)
      setRecentClients(clients.slice(0, 5));

      // Upcoming payments (next 10 unpaid)
      const upcoming = payments
        .filter(p => !p.is_paid)
        .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime())
        .slice(0, 10);
      setUpcomingPayments(upcoming);

    } catch (error) {
      console.error('Erro ao carregar dados do dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (isPending || loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600">Visão geral do seu negócio de IA</p>
          </div>
          <button
            onClick={loadDashboardData}
            disabled={loading}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Atualizar
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Total de Clientes"
            value={stats.totalClients}
            icon={<Users className="w-6 h-6" />}
            color="blue"
          />
          <StatCard
            title="Clientes Ativos"
            value={stats.activeClients}
            icon={<TrendingUp className="w-6 h-6" />}
            color="green"
          />
          <StatCard
            title="Pagamentos Pendentes"
            value={stats.pendingPayments}
            icon={<AlertCircle className="w-6 h-6" />}
            color="orange"
          />
          <StatCard
            title="Receita Total"
            value={`R$ ${stats.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
            icon={<CreditCard className="w-6 h-6" />}
            color="purple"
          />
        </div>

        {/* Test Checkout Section */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8 border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Teste o Sistema de Checkout</h2>
              <p className="text-gray-600 mb-6">
                Experimente o fluxo completo de pagamento em ambiente de teste. 
                Teste diferentes métodos de pagamento sem custo real.
              </p>
              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => navigate('/checkout/test')}
                  className="inline-flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <CreditCard className="w-5 h-5" />
                  <span>Checkout de Teste</span>
                </button>
                <button
                  onClick={() => navigate('/checkout?plan=professional&cycle=monthly')}
                  className="inline-flex items-center space-x-2 bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-all duration-200 shadow-lg border border-blue-200"
                >
                  <Users className="w-5 h-5" />
                  <span>Checkout Real</span>
                </button>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="text-6xl">💳</div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Clients */}
          <div className="bg-white/90 backdrop-blur-lg rounded-xl shadow-sm border border-blue-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Clientes Recentes</h2>
              <button 
                onClick={() => navigate('/clients')}
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                Ver todos
              </button>
            </div>
            <div className="space-y-3">
              {recentClients.length > 0 ? (
                recentClients.map((client) => (
                  <div key={client.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{client.name}</p>
                      <p className="text-sm text-gray-600">{client.email}</p>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      client.status === 'ativo' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      {client.status}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">Nenhum cliente cadastrado</p>
              )}
            </div>
          </div>

          {/* Upcoming Payments */}
          <div className="bg-white/90 backdrop-blur-lg rounded-xl shadow-sm border border-blue-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Próximos Pagamentos</h2>
              <button 
                onClick={() => navigate('/payments')}
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                Ver todos
              </button>
            </div>
            <div className="space-y-3">
              {upcomingPayments.length > 0 ? (
                upcomingPayments.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">
                        R$ {payment.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </p>
                      <p className="text-sm text-gray-600">
                        Vencimento: {new Date(payment.due_date).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      payment.type === 'implementation' 
                        ? 'bg-blue-100 text-blue-700' 
                        : 'bg-purple-100 text-purple-700'
                    }`}>
                      {payment.type === 'implementation' ? 'Implementação' : 'Mensalidade'}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">Nenhum pagamento pendente</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function StatCard({ title, value, icon, color }: {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: 'blue' | 'green' | 'orange' | 'purple';
}) {
  const colorClasses = {
    blue: 'bg-blue-500 text-white',
    green: 'bg-green-500 text-white',
    orange: 'bg-orange-500 text-white',
    purple: 'bg-purple-500 text-white',
  };

  return (
    <div className="bg-white/90 backdrop-blur-lg rounded-xl shadow-sm border border-blue-200 p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          {icon}
        </div>
      </div>
    </div>
  );
}
