import { useNavigate } from 'react-router';
import { Clock, CheckCircle2 } from 'lucide-react';

export default function CheckoutPending() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-amber-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-yellow-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
              alt="DIA Solutions AI" 
              className="h-10 w-auto"
            />
            <span className="font-bold text-gray-800 text-lg">Pagamento pendente</span>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-yellow-100 rounded-full mb-6">
            <Clock className="w-12 h-12 text-yellow-600" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Pagamento em análise
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Seu pagamento está sendo processado. Você receberá uma confirmação em breve.
          </p>
        </div>

        {/* Pending Details */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">O que acontece agora?</h2>
          
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                <span className="text-yellow-600 font-bold text-sm">1</span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Processamento</h3>
                <p className="text-gray-600">Seu pagamento está sendo analisado pelo Mercado Pago. Este processo pode levar alguns minutos.</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-bold text-sm">2</span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Confirmação</h3>
                <p className="text-gray-600">Assim que o pagamento for aprovado, você receberá um email de confirmação e sua conta será ativada automaticamente.</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Acesso liberado</h3>
                <p className="text-gray-600">Após a confirmação, você terá acesso completo a todos os recursos do seu plano.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
          <button
            onClick={() => navigate('/dashboard')}
            className="inline-flex items-center space-x-3 bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            <span>Ir para o Dashboard</span>
          </button>
          
          <button
            onClick={() => window.location.reload()}
            className="inline-flex items-center space-x-3 bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all duration-300 shadow-lg border border-gray-200"
          >
            <span>Verificar Status</span>
          </button>
        </div>

        {/* Support */}
        <div className="text-center mt-12">
          <div className="bg-blue-50 rounded-lg p-6 max-w-md mx-auto">
            <h3 className="font-semibold text-blue-900 mb-2">Ainda tem dúvidas?</h3>
            <p className="text-blue-800 text-sm mb-4">
              Se seu pagamento não for processado em até 24 horas, entre em contato conosco.
            </p>
            <a
              href="mailto:suporte@diasolutions.ai"
              className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium"
            >
              <span>Entrar em contato</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
