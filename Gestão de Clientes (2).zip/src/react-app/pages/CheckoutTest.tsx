import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { useAuth } from '@getmocha/users-service/react';
import { 
  Check, 
  Star, 
  Zap, 
  Crown, 
  Rocket, 
  CreditCard,
  Shield,
  ArrowLeft,
  Loader2,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';

interface Plan {
  id: string;
  name: string;
  icon: React.ReactNode;
  monthlyPrice: number;
  annualPrice: number;
  description: string;
  features: string[];
  recommended?: boolean;
  maxClients: number | 'unlimited';
  maxTemplates: number | 'unlimited';
}

const plans: Plan[] = [
  {
    id: 'starter',
    name: 'Starter',
    icon: <Star className="w-6 h-6" />,
    monthlyPrice: 19.90,
    annualPrice: 199,
    description: 'Perfeito para agências iniciantes',
    maxClients: 20,
    maxTemplates: 3,
    features: [
      'Até 20 clientes',
      '3 templates de checklist',
      'Controle de pagamentos',
      'Dashboard básico',
      'Suporte por email',
      'Relatórios mensais'
    ]
  },
  {
    id: 'professional',
    name: 'Professional',
    icon: <Zap className="w-6 h-6" />,
    monthlyPrice: 39.90,
    annualPrice: 399,
    description: 'Ideal para agências em crescimento',
    recommended: true,
    maxClients: 100,
    maxTemplates: 10,
    features: [
      'Até 100 clientes',
      '10 templates de checklist',
      'Controle avançado de pagamentos',
      'Dashboard completo com métricas',
      'Relatórios personalizados',
      'Suporte prioritário',
      'Automações básicas',
      'Backup automático'
    ]
  },
  {
    id: 'business',
    name: 'Business',
    icon: <Crown className="w-6 h-6" />,
    monthlyPrice: 59.90,
    annualPrice: 599,
    description: 'Para agências estabelecidas',
    maxClients: 500,
    maxTemplates: 'unlimited',
    features: [
      'Até 500 clientes',
      'Templates ilimitados',
      'Gestão multi-usuário',
      'Analytics avançados',
      'API para integrações',
      'White-label disponível',
      'Suporte telefônico',
      'Treinamento personalizado'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    icon: <Rocket className="w-6 h-6" />,
    monthlyPrice: 99.90,
    annualPrice: 999,
    description: 'Solução completa para grandes agências',
    maxClients: 'unlimited',
    maxTemplates: 'unlimited',
    features: [
      'Clientes ilimitados',
      'Templates ilimitados',
      'Multi-tenant completo',
      'Relatórios executivos',
      'Integrações customizadas',
      'Suporte dedicado 24/7',
      'SLA garantido',
      'Onboarding premium',
      'Consultoria estratégica'
    ]
  }
];

export default function CheckoutTest() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'credit_card' | 'pix' | 'boleto' | 'stripe'>('stripe');
  const [step, setStep] = useState<'plan' | 'payment' | 'processing' | 'success' | 'error'>('plan');
  const [error, setError] = useState<string | null>(null);
  const [subscriptionData, setSubscriptionData] = useState<any>(null);

  // Simulated payment data for testing
  const [customerData, setCustomerData] = useState({
    name: user?.google_user_data?.name || '',
    email: user?.email || '',
    phone: '',
    document: '',
    address: '',
    city: '',
    state: '',
    zipCode: ''
  });

  // Credit card data for testing
  const [cardData, setCardData] = useState({
    number: '',
    holderName: '',
    expiryMonth: '',
    expiryYear: '',
    ccv: ''
  });

  useEffect(() => {
    const planId = searchParams.get('plan');
    const cycle = searchParams.get('cycle') as 'monthly' | 'annual';
    
    if (planId) {
      const plan = plans.find(p => p.id === planId);
      if (plan) {
        setSelectedPlan(plan);
      }
    }
    
    if (cycle) {
      setBillingCycle(cycle);
    }
  }, [searchParams]);

  // Allow access without login for testing purposes

  const getPrice = (plan: Plan) => {
    return billingCycle === 'annual' ? plan.annualPrice : plan.monthlyPrice;
  };

  const getSavings = (plan: Plan) => {
    const monthlyTotal = plan.monthlyPrice * 12;
    const savings = monthlyTotal - plan.annualPrice;
    return Math.round((savings / monthlyTotal) * 100);
  };

  const handlePlanSelect = (plan: Plan) => {
    setSelectedPlan(plan);
    setStep('payment');
  };

  const handleBackToPlan = () => {
    setStep('plan');
    setError(null);
  };

  const simulateAsaasPayment = async () => {
    // Simulate different payment outcomes for testing
    const scenarios = ['success', 'pending', 'error'];
    const randomScenario = scenarios[Math.floor(Math.random() * scenarios.length)];
    
    // Add longer delay to simulate real payment processing
    await new Promise(resolve => setTimeout(resolve, 3000 + Math.random() * 2000));
    
    if (randomScenario === 'error') {
      throw new Error('Falha na comunicação com o gateway de pagamento');
    }
    
    return {
      id: `pay_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      status: randomScenario === 'success' ? 'CONFIRMED' : 'PENDING',
      invoiceUrl: randomScenario === 'pending' ? `https://sandbox.asaas.com/i/${Math.random().toString(36).substr(2, 10)}` : null,
      pixCode: paymentMethod === 'pix' ? `00020126370014BR.GOV.BCB.PIX0115${Math.random().toString(36).substr(2, 10)}5204000053039865802BR5915DIA SOLUTIONS AI6009SAO PAULO` : null,
      barCode: paymentMethod === 'boleto' ? `23793.38128 60047.321000 00012.345678 9 87654321000123` : null
    };
  };

  const handleCheckout = async () => {
    if (!selectedPlan) return;

    setIsProcessing(true);
    setStep('processing');
    setError(null);

    try {
      // First create subscription in our system
      const subscriptionResponse = await fetch('/api/subscriptions/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Test-Mode': 'true'
        },
        body: JSON.stringify({
          planId: selectedPlan.id,
          billingCycle,
          paymentMethod,
          amount: getPrice(selectedPlan),
        }),
      });

      if (!subscriptionResponse.ok) {
        throw new Error('Falha ao criar assinatura');
      }

      const subscription = await subscriptionResponse.json();
      
      // Simulate payment with Asaas
      const paymentResult = await simulateAsaasPayment();
      
      setSubscriptionData({
        ...subscription,
        payment: paymentResult,
        plan: selectedPlan,
        billingCycle,
        amount: getPrice(selectedPlan)
      });

      if (paymentResult.status === 'CONFIRMED') {
        setStep('success');
      } else {
        setStep('success'); // For demo, treat pending as success with instructions
      }

    } catch (error) {
      console.error('Checkout error:', error);
      setError(error instanceof Error ? error.message : 'Erro no processamento do pagamento');
      setStep('error');
    } finally {
      setIsProcessing(false);
    }
  };

  const renderPaymentInstructions = () => {
    if (!subscriptionData?.payment) return null;

    const { payment } = subscriptionData;

    if (payment.status === 'CONFIRMED') {
      return (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <div className="flex items-center space-x-3">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            <div>
              <h4 className="font-semibold text-green-800">Pagamento Confirmado!</h4>
              <p className="text-green-700">Sua assinatura foi ativada imediatamente.</p>
            </div>
          </div>
        </div>
      );
    }

    if (paymentMethod === 'pix' && payment.pixCode) {
      return (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-blue-800 mb-3">Pague com PIX</h4>
          <div className="bg-white p-3 rounded border text-xs font-mono break-all mb-3">
            {payment.pixCode}
          </div>
          <p className="text-blue-700 text-sm">
            Copie o código PIX acima ou escaneie o QR Code para realizar o pagamento.
            Sua assinatura será ativada automaticamente após a confirmação.
          </p>
        </div>
      );
    }

    if (paymentMethod === 'boleto' && payment.barCode) {
      return (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-yellow-800 mb-3">Boleto Bancário</h4>
          <div className="bg-white p-3 rounded border text-xs font-mono mb-3">
            {payment.barCode}
          </div>
          <p className="text-yellow-700 text-sm">
            Use o código de barras acima para pagamento ou acesse o link do boleto.
            Vencimento: {new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR')}
          </p>
          {payment.invoiceUrl && (
            <a 
              href={payment.invoiceUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block mt-2 text-yellow-800 hover:text-yellow-900 underline"
            >
              Visualizar Boleto
            </a>
          )}
        </div>
      );
    }

    return null;
  };

  // Plan Selection Step
  if (step === 'plan') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <header className="bg-white/90 backdrop-blur-lg border-b border-blue-200 px-6 py-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Voltar</span>
              </button>
              <div className="h-6 w-px bg-gray-300" />
              <div className="flex items-center space-x-3">
                <img 
                  src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
                  alt="DIA Solutions AI" 
                  className="h-10 w-auto"
                />
                <span className="font-bold text-gray-800 text-lg">Checkout de Teste</span>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {user?.google_user_data?.picture && (
                <img
                  src={user.google_user_data.picture}
                  alt={user.google_user_data.name || user.email}
                  className="w-8 h-8 rounded-full"
                />
              )}
              <span className="text-sm text-gray-700">
                {user?.google_user_data?.name || user?.email || 'Usuário de Teste'}
              </span>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 bg-orange-100 text-orange-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <AlertCircle className="w-4 h-4" />
              <span>Ambiente de Teste - Nenhuma cobrança será realizada</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Escolha Seu Plano
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Teste a experiência completa de checkout da plataforma
            </p>
            
            <div className="flex items-center justify-center space-x-4 mb-8">
              <span className={`text-lg ${billingCycle === 'monthly' ? 'text-blue-600 font-semibold' : 'text-gray-600'}`}>
                Mensal
              </span>
              <button
                onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  billingCycle === 'annual' ? 'bg-blue-600' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    billingCycle === 'annual' ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
              <span className={`text-lg ${billingCycle === 'annual' ? 'text-blue-600 font-semibold' : 'text-gray-600'}`}>
                Anual
              </span>
              {billingCycle === 'annual' && (
                <span className="bg-green-100 text-green-800 text-sm px-3 py-1 rounded-full font-medium">
                  Economize até 20%
                </span>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className={`relative bg-white rounded-2xl p-6 cursor-pointer transition-all duration-300 hover:scale-105 ${
                  plan.recommended
                    ? 'border-2 border-blue-500 shadow-xl'
                    : 'border border-gray-200 shadow-lg hover:shadow-xl'
                }`}
                onClick={() => handlePlanSelect(plan)}
              >
                {plan.recommended && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                      Mais Popular
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <div className={`inline-flex p-3 rounded-full mb-4 ${
                    plan.recommended ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {plan.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-4">{plan.description}</p>
                  <div className="mb-2">
                    <span className="text-3xl font-bold text-gray-900">
                      R$ {getPrice(plan).toFixed(2).replace('.', ',')}
                    </span>
                    <span className="text-gray-600">/{billingCycle === 'annual' ? 'ano' : 'mês'}</span>
                  </div>
                  {billingCycle === 'annual' && (
                    <p className="text-green-600 text-sm font-medium">
                      Economize {getSavings(plan)}% no plano anual
                    </p>
                  )}
                </div>

                <div className="space-y-3 mb-6">
                  {plan.features.slice(0, 4).map((feature, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </div>
                  ))}
                  {plan.features.length > 4 && (
                    <p className="text-gray-500 text-sm">+{plan.features.length - 4} funcionalidades</p>
                  )}
                </div>

                <button className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-200 ${
                  plan.recommended
                    ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg hover:shadow-xl'
                    : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                }`}>
                  Testar Plano
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Payment Step
  if (step === 'payment') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <header className="bg-white/90 backdrop-blur-lg border-b border-blue-200 px-6 py-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={handleBackToPlan}
                className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Voltar</span>
              </button>
              <div className="h-6 w-px bg-gray-300" />
              <div className="flex items-center space-x-3">
                <img 
                  src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
                  alt="DIA Solutions AI" 
                  className="h-10 w-auto"
                />
                <span className="font-bold text-gray-800 text-lg">Finalizar Pedido</span>
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Plan Summary */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Resumo do Plano</h3>
              
              {selectedPlan && (
                <>
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="text-blue-600">{selectedPlan.icon}</div>
                    <div>
                      <h4 className="text-xl font-bold text-gray-900">{selectedPlan.name}</h4>
                      <p className="text-gray-600">{selectedPlan.description}</p>
                    </div>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Plano {selectedPlan.name}</span>
                      <span className="font-semibold">
                        R$ {getPrice(selectedPlan).toFixed(2).replace('.', ',')}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Cobrança</span>
                      <span className="text-gray-600 capitalize">{billingCycle === 'annual' ? 'Anual' : 'Mensal'}</span>
                    </div>
                    {billingCycle === 'annual' && (
                      <div className="flex justify-between items-center text-green-600">
                        <span>Desconto anual</span>
                        <span>-{getSavings(selectedPlan)}%</span>
                      </div>
                    )}
                    <hr className="border-gray-200" />
                    <div className="flex justify-between items-center text-lg font-bold">
                      <span>Total</span>
                      <span>R$ {getPrice(selectedPlan).toFixed(2).replace('.', ',')}</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h5 className="font-semibold text-gray-900">Incluído no plano:</h5>
                    {selectedPlan.features.map((feature, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <Check className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Payment Form */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Informações de Pagamento</h3>
              
              {/* Payment Method Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Método de Pagamento (Teste)
                </label>
                <div className="space-y-3">
                  <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="credit_card"
                      checked={paymentMethod === 'credit_card'}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="text-blue-600"
                    />
                    <CreditCard className="w-5 h-5 text-gray-600" />
                    <span className="text-gray-700">Cartão de Crédito (Simulado)</span>
                  </label>
                  <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="pix"
                      checked={paymentMethod === 'pix'}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="text-blue-600"
                    />
                    <div className="w-5 h-5 bg-green-500 rounded"></div>
                    <span className="text-gray-700">PIX (Simulado)</span>
                  </label>
                  <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="boleto"
                      checked={paymentMethod === 'boleto'}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="text-blue-600"
                    />
                    <div className="w-5 h-5 bg-yellow-500 rounded"></div>
                    <span className="text-gray-700">Boleto Bancário (Simulado)</span>
                  </label>
                  <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="stripe"
                      checked={paymentMethod === 'stripe'}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="text-blue-600"
                    />
                    <div className="w-5 h-5 bg-purple-500 rounded flex items-center justify-center">
                      <span className="text-white text-xs font-bold">S</span>
                    </div>
                    <span className="text-gray-700">Stripe (Simulado)</span>
                  </label>
                </div>
              </div>

              {/* Customer Information */}
              <div className="space-y-4 mb-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nome Completo
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={customerData.name}
                      onChange={(e) => setCustomerData({...customerData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={customerData.email}
                      onChange={(e) => setCustomerData({...customerData, email: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Telefone
                    </label>
                    <input
                      type="tel"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={customerData.phone}
                      onChange={(e) => setCustomerData({...customerData, phone: e.target.value})}
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      CPF/CNPJ
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={customerData.document}
                      onChange={(e) => setCustomerData({...customerData, document: e.target.value})}
                      placeholder="000.000.000-00"
                    />
                  </div>
                </div>
              </div>

              {/* Credit Card Details - Only shown when credit card is selected */}
              {paymentMethod === 'credit_card' && (
                <div className="space-y-4 mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h4 className="font-semibold text-gray-900 mb-3">
                    Dados do Cartão de Crédito
                  </h4>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Número do Cartão
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg"
                      value={cardData.number}
                      onChange={(e) => {
                        // Format card number with spaces
                        const value = e.target.value.replace(/\s/g, '').replace(/(.{4})/g, '$1 ').trim();
                        if (value.replace(/\s/g, '').length <= 16) {
                          setCardData({...cardData, number: value});
                        }
                      }}
                      placeholder="1234 5678 9012 3456"
                      maxLength={19}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nome do Portador
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={cardData.holderName}
                      onChange={(e) => setCardData({...cardData, holderName: e.target.value.toUpperCase()})}
                      placeholder="NOME COMO IMPRESSO NO CARTÃO"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Mês
                      </label>
                      <select
                        className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={cardData.expiryMonth}
                        onChange={(e) => setCardData({...cardData, expiryMonth: e.target.value})}
                      >
                        <option value="">Mês</option>
                        {Array.from({length: 12}, (_, i) => i + 1).map(month => (
                          <option key={month} value={month.toString().padStart(2, '0')}>
                            {month.toString().padStart(2, '0')}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Ano
                      </label>
                      <select
                        className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={cardData.expiryYear}
                        onChange={(e) => setCardData({...cardData, expiryYear: e.target.value})}
                      >
                        <option value="">Ano</option>
                        {Array.from({length: 10}, (_, i) => new Date().getFullYear() + i).map(year => (
                          <option key={year} value={year.toString()}>
                            {year}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        CCV
                      </label>
                      <input
                        type="text"
                        className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-center"
                        value={cardData.ccv}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          if (value.length <= 4) {
                            setCardData({...cardData, ccv: value});
                          }
                        }}
                        placeholder="123"
                        maxLength={4}
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 text-sm text-gray-600 mt-3">
                    <Shield className="w-4 h-4" />
                    <span>Seus dados estão protegidos com criptografia SSL</span>
                  </div>
                </div>
              )}

              {/* Security Notice */}
              <div className="flex items-start space-x-3 p-4 bg-orange-50 rounded-lg mb-6">
                <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                <div className="text-sm text-orange-800">
                  <p className="font-medium">Ambiente de Teste</p>
                  <p>Este é um checkout de demonstração. Nenhuma cobrança real será processada.</p>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={handleCheckout}
                disabled={isProcessing}
                className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {selectedPlan && `Testar Pagamento - R$ ${getPrice(selectedPlan).toFixed(2).replace('.', ',')}`}
              </button>

              <p className="text-xs text-gray-500 text-center mt-4">
                Este é um ambiente de teste. Experimente diferentes cenários de pagamento.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Processing Step
  if (step === 'processing') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="bg-white rounded-2xl p-12 shadow-2xl text-center max-w-md mx-auto">
          <div className="animate-spin mb-6 mx-auto">
            <Loader2 className="w-16 h-16 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Processando Pagamento
          </h2>
          <p className="text-gray-600 mb-6">
            Aguarde enquanto simulamos o processamento do seu pagamento...
          </p>
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
          </div>
        </div>
      </div>
    );
  }

  // Success Step
  if (step === 'success') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-indigo-50">
        <header className="bg-white/90 backdrop-blur-lg border-b border-green-200 px-6 py-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src="https://mocha-cdn.com/01983727-8a4b-757e-8bf5-6c2d413a9dd5/WhatsApp-Image-2025-06-10-at-12.15.5.png" 
                alt="DIA Solutions AI" 
                className="h-10 w-auto"
              />
              <span className="font-bold text-gray-800 text-lg">Teste Concluído</span>
            </div>
          </div>
        </header>

        <div className="max-w-4xl mx-auto px-6 py-16">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-green-100 rounded-full mb-6">
              <CheckCircle2 className="w-12 h-12 text-green-600" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Teste Realizado com Sucesso!
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              O checkout foi processado com sucesso. Veja os detalhes da simulação abaixo.
            </p>
          </div>

          {/* Payment Instructions */}
          {renderPaymentInstructions()}

          {/* Test Results */}
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Detalhes do Teste</h2>
            
            {subscriptionData && (
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600">ID da Transação</p>
                    <p className="font-semibold text-gray-900">{subscriptionData.payment?.id}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-600">Plano</p>
                    <p className="font-semibold text-gray-900">{subscriptionData.plan?.name}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-600">Valor</p>
                    <p className="font-semibold text-gray-900">
                      R$ {subscriptionData.amount?.toFixed(2).replace('.', ',')} / {subscriptionData.billingCycle === 'annual' ? 'ano' : 'mês'}
                    </p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600">Método de Pagamento</p>
                    <p className="font-semibold text-gray-900 capitalize">
                      {paymentMethod === 'credit_card' ? 'Cartão de Crédito' : 
                       paymentMethod === 'pix' ? 'PIX' : 
                       paymentMethod === 'stripe' ? 'Stripe' : 'Boleto Bancário'}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-600">Status</p>
                    <p className="font-semibold text-green-600">
                      {subscriptionData.payment?.status === 'CONFIRMED' ? 'Confirmado' : 'Pendente'}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-600">Data do Teste</p>
                    <p className="font-semibold text-gray-900">
                      {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR')}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center space-x-3 bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              <span>Ir para o Dashboard</span>
            </button>
            
            <button
              onClick={() => {
                setStep('plan');
                setSelectedPlan(null);
                setError(null);
                setSubscriptionData(null);
              }}
              className="inline-flex items-center space-x-3 bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all duration-300 shadow-lg border border-gray-200"
            >
              <span>Testar Novamente</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Error Step
  if (step === 'error') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 flex items-center justify-center">
        <div className="bg-white rounded-2xl p-12 shadow-2xl text-center max-w-md mx-auto">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Erro no Processamento
          </h2>
          <p className="text-gray-600 mb-6">
            {error || 'Ocorreu um erro durante o processamento do pagamento de teste.'}
          </p>
          <div className="space-y-3">
            <button
              onClick={() => {
                setStep('payment');
                setError(null);
              }}
              className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Tentar Novamente
            </button>
            <button
              onClick={handleBackToPlan}
              className="w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-200 transition-colors"
            >
              Escolher Outro Plano
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
